# 采购竞价系统 - 后台服务（Spring Boot）

为前端 `Purchase-Bidding-Demo` 提供接口服务：登录认证、用户管理、采购需求发布、供应商报价、排名及中标确认。

## 技术栈

| 组件 | 版本 |
| --- | --- |
| JDK | 17 |
| Spring Boot | 3.2.5 |
| MyBatis | 3.5.16（mybatis-spring-boot-starter 3.0.3） |
| MySQL | 5.7+ / 8.0 |
| JWT | jjwt 0.12.6 |
| 接口文档 | springdoc-openapi 2.5.0（Swagger UI） |
| 构建 | Maven 3.9+（已内置 Maven Wrapper） |

## 目录结构

```
purchase-bidding-server/
├── mvnw / mvnw.cmd / .mvn/wrapper/     # Maven Wrapper
├── pom.xml
├── src/main/java/com/songlin/bidding/
│   ├── BiddingApplication.java         # 启动类
│   ├── common/                         # Result / PageResult / BusinessException / 全局异常处理 / 登录上下文
│   ├── config/                         # 跨域与拦截器配置、密码加密器、演示数据初始化
│   ├── interceptor/AuthInterceptor.java# JWT 登录鉴权
│   ├── util/                           # JwtUtil / NoGenerator（单号生成）/ DateTimeUtil
│   ├── entity/                         # 6 张表对应实体
│   ├── dto/                            # 请求与响应对象（字段与前端一一对应）
│   ├── mapper/                         # MyBatis 接口
│   ├── service/ + service/impl/        # 业务实现
│   └── controller/                     # 5 个接口控制器
└── src/main/resources/
    ├── application.yml
    ├── db/schema.sql                   # 建库建表脚本
    └── mapper/*.xml
```

## 数据库设计

数据库：`purchase_bidding`

| 表名 | 说明 | 主要字段 |
| --- | --- | --- |
| `sys_user` | 系统用户（登录 + 用户管理） | id、username、password、phone、name、email、company、role(admin/purchaser/supplier)、enabled、create_time、deleted |
| `purchase_requirement` | 采购需求单 | id、req_no（XQ+yyyyMMdd+4位序号）、quote_deadline、deliver_date、creator、create_time、modifier、modify_time、remark |
| `requirement_item` | 需求商品明细 | id、requirement_id、part_no、replace_no、part_name、quantity、unit、spec、purchase_remark、published、sort_order |
| `quotation` | 供应商报价单 | id、quote_no（BJ+yyyyMMdd+4位序号）、requirement_id、req_no、quote_deadline、deliver_date、confirm_deliver_date、quote_person、quote_user_id、quote_time、total_amount，唯一键 `(requirement_id, quote_person)` 保证一个供应商一份报价单可多次编辑 |
| `quotation_item` | 报价商品明细 | id、quotation_id、requirement_item_id、part_no、part_name、quantity、unit_price、quote_remark、sort_order |
| `award_result` | 中标结果 | id、requirement_id（唯一，一个需求一条中标）、quotation_id、quote_no、supplier_name、award_price、confirm_deliver_date、confirm_time |

### 初始化步骤

```bash
# 1. 建库建表
mysql -u root -p < src/main/resources/db/schema.sql

# 2. 修改 application.yml 中的数据库连接（账号/密码）
```

演示账号在服务首次启动时自动写入（密码统一 `123456`）：“admin（管理员）、zhangsan（采购员）、lisi / wangwu（供应商）”。

## 启动方式

```bash
# 方式一：Maven Wrapper（首次运行会自动下载 Maven）
mvnw.cmd spring-boot:run

# 方式二：已安装 Maven
mvn spring-boot:run

# 方式三：IDEA 直接运行 BiddingApplication
```

服务端口：`8080`，接口统一前缀 `/api`。

### 接口文档（Swagger）

启动服务后访问：

| 入口 | 地址 |
| --- | --- |
| Swagger UI | http://localhost:8080/swagger-ui.html |
| OpenAPI JSON | http://localhost:8080/v3/api-docs |
| OpenAPI YAML | http://localhost:8080/v3/api-docs.yaml |

**如何在 Swagger UI 中调试带鉴权的接口：**

1. 调用 `POST /api/auth/login`，在返回的 `data.token` 中复制 token
2. 点击页面右上角 **Authorize**，填入 `Bearer {token}`（注意 `Bearer` 后有空格），点击 Authorize → Close
3. 之后调用其它接口会自动携带 `Authorization` 请求头

> 登录接口已标记为无需鉴权；`springdoc.paths-to-match` 仅扫描 `/api/**`，不会暴露其它端点。
> 如需导出离线文档，可直接保存 `/v3/api-docs` 的 JSON，用 Postman / Apifox 导入。

前端已配置 Vite 代理：`/api` → `http://127.0.0.1:8080`，直接 `npm run dev` 即可联调。

## 接口清单

统一返回结构：`{ "code": 0, "message": "ok", "data": ... }`，`code != 0` 为业务异常；`401` 表示未登录或登录过期。
除登录接口外，请求头需携带 `Authorization: Bearer <token>`。

### 登录认证

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/auth/login` | 登录，入参 `{username, password}`，返回 token 与用户信息 |
| GET | `/api/auth/info` | 获取当前登录用户信息 |
| POST | `/api/auth/logout` | 退出登录 |

### 用户管理

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/users` | 分页查询，条件：phone、name、role、enabled、pageNum、pageSize |
| POST | `/api/users` | 新增用户（password 选填，默认 123456） |
| PUT | `/api/users/{id}` | 编辑用户 |
| DELETE | `/api/users/{id}` | 删除用户（逻辑删除，不能删除当前登录账号） |
| GET | `/api/users/phone-exists` | 手机号是否已被占用（phone、excludeId） |

### 采购需求

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/requirements` | 分页查询，条件：reqNo、keyword（配件图号/名称）、deadlineStart、deadlineEnd、status（quoting/expired/awarded） |
| GET | `/api/requirements/{id}` | 需求详情（含商品清单） |
| GET | `/api/requirements/next-no` | 预生成需求单号 |
| POST | `/api/requirements` | 发布/保存需求单（含商品清单），发布后清空该需求的历史报价与中标记录 |

### 供应商报价

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/quotations` | 我的历史报价单据（仅当前登录供应商），条件：reqNo、quoteNo、status、quoteStart、quoteEnd |
| GET | `/api/quotations/pending-list` | 待报价需求（未截止且未中标，含 myQuote 标记） |
| GET | `/api/quotations/edit-data?requirementId=` | 报价编辑页数据：上游需求只读信息 + 本人已报价回填 |
| GET | `/api/quotations/{id}` | 报价单详情（含商品报价明细） |
| POST | `/api/quotations` | 提交报价，截止前可多次提交覆盖（同一需求 + 同一报价人一份报价单） |

### 排名及采购确认

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/confirm/list` | 报价单排名列表，条件：reqNo、quoteNo、supplier、status（quoting/pending/awarded） |
| GET | `/api/confirm/{quotationId}` | 报价单详情（含明细、排名与状态） |
| POST | `/api/confirm/award` | 确认中标，入参 `{quotationId}` |

## 核心业务规则

- **需求单号**：`XQ + yyyyMMdd + 4位序号`，保存时服务端生成，不可编辑
- **报价单号**：`BJ + yyyyMMdd + 4位序号`，首次提交时生成
- **报价规则**：报价截止前可多次编辑；截止后禁止提交/修改；需求已中标后禁止再报价
- **排名规则**：截止前不排名、金额对采购方不可见（返回状态 `quoting`）；截止后按报价金额从低到高排名，第 1 名标注"推荐中标"
- **中标规则**：一个需求单仅一条中标记录，仅"待确认"状态的报价单可确认中标；重新发布需求会清空历史报价与中标记录
- **登录账号**：用户管理的"账号（手机号）"即登录账号，新增用户默认密码 `123456`
