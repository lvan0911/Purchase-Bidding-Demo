@REM ----------------------------------------------------------------------------
@REM Maven Wrapper startup script for Windows
@REM Usage: mvnw.cmd clean compile    mvnw.cmd spring-boot:run
@REM The first run downloads the Maven distribution declared in
@REM .mvn\wrapper\maven-wrapper.properties
@REM ----------------------------------------------------------------------------
@echo off
setlocal

set MAVEN_PROJECTBASEDIR=%~dp0
if "%MAVEN_PROJECTBASEDIR:~-1%"=="\" set MAVEN_PROJECTBASEDIR=%MAVEN_PROJECTBASEDIR:~0,-1%

set WRAPPER_JAR=%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar
set WRAPPER_LAUNCHER=org.apache.maven.wrapper.MavenWrapperMain

if not exist "%WRAPPER_JAR%" (
  echo [mvnw] Not found: %WRAPPER_JAR%
  echo [mvnw] Keep .mvn\wrapper\maven-wrapper.jar in place, or use the mvn command.
  exit /B 1
)

java -classpath "%WRAPPER_JAR%" "-Dmaven.multiModuleProjectDirectory=%MAVEN_PROJECTBASEDIR%" %WRAPPER_LAUNCHER% %*

exit /B %ERRORLEVEL%
