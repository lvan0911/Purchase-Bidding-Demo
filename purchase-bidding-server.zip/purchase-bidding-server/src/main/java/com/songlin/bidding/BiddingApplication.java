package com.songlin.bidding;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 松林科技采购竞价系统 - 后台服务启动类
 */
@MapperScan("com.songlin.bidding.mapper")
@SpringBootApplication
public class BiddingApplication {

  public static void main(String[] args) {
    SpringApplication.run(BiddingApplication.class, args);
  }
}
