package com.songlin.bidding.common;

import lombok.Getter;

/**
 * 业务异常：返回给前端的提示信息
 */
@Getter
public class BusinessException extends RuntimeException {

  private final int code;

  public BusinessException(String message) {
    super(message);
    this.code = Result.FAIL_CODE;
  }

  public BusinessException(int code, String message) {
    super(message);
    this.code = code;
  }
}
