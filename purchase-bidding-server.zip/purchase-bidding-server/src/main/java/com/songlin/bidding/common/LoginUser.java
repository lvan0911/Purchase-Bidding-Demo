package com.songlin.bidding.common;

import lombok.Data;

import java.io.Serializable;

/**
 * 登录用户上下文（ThreadLocal）
 */
@Data
public class LoginUser implements Serializable {

  private static final long serialVersionUID = 1L;

  private Long id;
  private String username;
  private String name;
  private String role;
  private String company;

  public static LoginUser of(Long id, String username, String name, String role, String company) {
    LoginUser u = new LoginUser();
    u.setId(id);
    u.setUsername(username);
    u.setName(name);
    u.setRole(role);
    u.setCompany(company);
    return u;
  }
}
