package com.songlin.bidding.common;

import lombok.Data;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * 分页返回结构：与前端 a-table pagination 对齐
 * pageNum 从 1 开始
 */
@Data
public class PageResult<T> implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<T> list = Collections.emptyList();
  private long total = 0;
  private int pageNum = 1;
  private int pageSize = 10;

  public static <T> PageResult<T> of(List<T> list, long total, int pageNum, int pageSize) {
    PageResult<T> r = new PageResult<>();
    r.setList(list == null ? Collections.emptyList() : list);
    r.setTotal(total);
    r.setPageNum(pageNum);
    r.setPageSize(pageSize);
    return r;
  }
}
