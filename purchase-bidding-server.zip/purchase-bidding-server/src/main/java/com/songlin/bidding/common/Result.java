package com.songlin.bidding.common;

import lombok.Data;

import java.io.Serializable;

/**
 * 统一接口返回结构：{ code, message, data }
 * code = 0 表示成功，非 0 表示业务/系统异常
 */
@Data
public class Result<T> implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final int SUCCESS_CODE = 0;
  public static final int FAIL_CODE = 500;

  private int code;
  private String message;
  private T data;

  public static <T> Result<T> success() {
    return success(null);
  }

  public static <T> Result<T> success(T data) {
    Result<T> r = new Result<>();
    r.setCode(SUCCESS_CODE);
    r.setMessage("ok");
    r.setData(data);
    return r;
  }

  public static <T> Result<T> fail(String message) {
    return fail(FAIL_CODE, message);
  }

  public static <T> Result<T> fail(int code, String message) {
    Result<T> r = new Result<>();
    r.setCode(code);
    r.setMessage(message);
    return r;
  }
}
