package com.songlin.bidding.common;

/**
 * 当前登录用户上下文（ThreadLocal）
 */
public final class UserContext {

  private static final ThreadLocal<LoginUser> LOCAL = new ThreadLocal<>();

  private UserContext() {
  }

  public static void set(LoginUser user) {
    LOCAL.set(user);
  }

  public static LoginUser get() {
    return LOCAL.get();
  }

  /** 当前登录用户名（报价人、创建人等默认取该值） */
  public static String currentUsername() {
    LoginUser u = LOCAL.get();
    return u == null ? null : u.getUsername();
  }

  /** 当前登录用户姓名（sys_user.name），用于采购需求创建人/修改人显示 */
  public static String currentName() {
    LoginUser u = LOCAL.get();
    if (u == null) {
      return null;
    }
    return (u.getName() != null && !u.getName().isBlank()) ? u.getName() : u.getUsername();
  }

  public static Long currentUserId() {
    LoginUser u = LOCAL.get();
    return u == null ? null : u.getId();
  }

  /** 当前登录用户角色 */
  public static String currentRole() {
    LoginUser u = LOCAL.get();
    return u == null ? null : u.getRole();
  }

  /** 是否管理员 */
  public static boolean isAdmin() {
    return "admin".equals(currentRole());
  }

  /** 是否采购员 */
  public static boolean isPurchaser() {
    return "purchaser".equals(currentRole());
  }

  /** 是否供应商 */
  public static boolean isSupplier() {
    return "supplier".equals(currentRole());
  }

  public static void clear() {
    LOCAL.remove();
  }
}
