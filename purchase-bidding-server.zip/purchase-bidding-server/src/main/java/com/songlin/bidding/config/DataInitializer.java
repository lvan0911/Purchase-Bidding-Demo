package com.songlin.bidding.config;

import com.songlin.bidding.entity.SysUser;
import com.songlin.bidding.mapper.SysUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * 演示数据初始化：sys_user 表为空时写入 4 个演示账号（密码 123456）
 * 生产环境可删除本类
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

  private final SysUserMapper sysUserMapper;
  private final PasswordEncoder passwordEncoder;

  @Override
  public void run(String... args) {
    if (sysUserMapper.countAll() > 0) {
      return;
    }
    String encoded = passwordEncoder.encode("123456");
    insert("admin", encoded, "13800000001", "系统管理员", "admin@songlin.com", "松林科技有限公司", "admin");
    insert("zhangsan", encoded, "13800000002", "张三", "zhangsan@songlin.com", "松林科技有限公司", "purchaser");
    insert("lisi", encoded, "13800000003", "李四", "lisi@supplier-a.com", "供应商A公司", "supplier");
    insert("wangwu", encoded, "13800000004", "王五", "wangwu@supplier-b.com", "供应商B公司", "supplier");
    log.info("演示账号初始化完成：admin/zhangsan/lisi/wangwu，密码 123456");
  }

  private void insert(String username, String password, String phone, String name,
                      String email, String company, String role) {
    SysUser u = new SysUser();
    u.setUsername(username);
    u.setPassword(password);
    u.setPhone(phone);
    u.setName(name);
    u.setEmail(email);
    u.setCompany(company);
    u.setRole(role);
    u.setEnabled(1);
    sysUserMapper.insert(u);
  }
}
