package com.songlin.bidding.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger / OpenAPI 接口文档配置
 *
 * <p>访问地址（服务端口 8080）：
 * <ul>
 *   <li>Swagger UI：http://localhost:8080/swagger-ui.html</li>
 *   <li>OpenAPI JSON：http://localhost:8080/v3/api-docs</li>
 * </ul>
 *
 * <p>鉴权说明：除登录接口外，其余接口需在 Swagger UI 右上角 Authorize 中填入
 * <code>Bearer {token}</code>（token 由 /api/auth/login 返回）。
 */
@Configuration
public class OpenApiConfig {

  private static final String SECURITY_SCHEME = "bearer-jwt";

  @Bean
  public OpenAPI biddingOpenApi() {
    return new OpenAPI()
        .info(new Info()
            .title("松林科技采购竞价系统 - 接口文档")
            .description("登录认证、用户管理、采购需求发布、供应商报价、排名及中标确认。"
                + "接口统一返回 { code, message, data }，code = 0 表示成功。")
            .version("1.0.0")
            .contact(new Contact().name("松林科技").email("admin@songlin.com"))
            .license(new License().name("内部使用")))
        .components(new Components()
            .addSecuritySchemes(SECURITY_SCHEME, new SecurityScheme()
                .name(SECURITY_SCHEME)
                .type(SecurityScheme.Type.HTTP)
                .scheme("bearer")
                .bearerFormat("JWT")
                .description("请求头格式：Authorization: Bearer {token}")))
        // 全局使用 JWT；登录接口通过 @SecurityRequirement 覆盖为空（见 AuthController）
        .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME));
  }
}
