package com.songlin.bidding.controller;

import com.songlin.bidding.common.Result;
import com.songlin.bidding.dto.LoginRequest;
import com.songlin.bidding.dto.LoginResponse;
import com.songlin.bidding.dto.UserInfoVO;
import com.songlin.bidding.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 登录认证接口
 */
@Tag(name = "登录认证", description = "登录、获取当前用户信息、退出登录")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

  private final AuthService authService;

  @Operation(
      summary = "登录",
      description = "支持使用登录账号或手机号登录，返回 JWT token 与当前用户信息（角色决定菜单与数据范围）")
  @PostMapping("/login")
  @SecurityRequirements // 登录接口无需鉴权，覆盖全局 Bearer 要求
  public Result<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
    return Result.success(authService.login(request));
  }

  @Operation(summary = "获取当前登录用户信息", description = "需携带 Authorization: Bearer {token}")
  @GetMapping("/info")
  public Result<UserInfoVO> info() {
    return Result.success(authService.currentUser());
  }

  @Operation(summary = "退出登录", description = "token 无状态，服务端不做失效处理，前端清除本地 token 即可")
  @PostMapping("/logout")
  public Result<Void> logout() {
    return Result.success();
  }
}
