package com.songlin.bidding.controller;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.Result;
import com.songlin.bidding.dto.AwardRequest;
import com.songlin.bidding.dto.ConfirmQuery;
import com.songlin.bidding.dto.QuotationVO;
import com.songlin.bidding.service.ConfirmService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 排名及采购确认接口
 */
@Tag(name = "排名及采购确认", description = "报价单排名列表（报价中不排名、金额不可见）、详情与确认中标")
@RestController
@RequestMapping("/api/confirm")
@RequiredArgsConstructor
public class ConfirmController {

  private final ConfirmService confirmService;

  @Operation(summary = "报价单排名列表", description = "仅返回报价已截止的报价单（未截止的不返回）；条件：reqNo / quoteNo / supplier / status（pending|awarded|lost）；截止后按金额升序给出 rank，第 1 名为推荐中标")
  @GetMapping("/list")
  public Result<PageResult<QuotationVO>> page(
      @Parameter(description = "查询条件与分页参数") ConfirmQuery query) {
    return Result.success(confirmService.page(query));
  }

  @Operation(summary = "报价单详情", description = "含商品报价明细、排名与状态")
  @GetMapping("/{quotationId}")
  public Result<QuotationVO> detail(
      @Parameter(description = "报价单 ID", required = true) @PathVariable Long quotationId) {
    return Result.success(confirmService.detail(quotationId));
  }

  @Operation(
      summary = "批量确认中标",
      description = "一次确认多个报价单中标，返回成功确认的条数。"
          + "约束：报价单须已截止且未中标；同一需求单只能确认一个中标报价单；"
          + "任一条校验不通过则整批回滚。")
  @PostMapping("/award")
  public Result<Integer> award(@Valid @RequestBody AwardRequest request) {
    return Result.success(confirmService.award(request));
  }
}
