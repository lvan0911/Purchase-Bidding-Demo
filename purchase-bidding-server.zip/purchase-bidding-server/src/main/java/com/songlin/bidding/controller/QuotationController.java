package com.songlin.bidding.controller;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.Result;
import com.songlin.bidding.dto.PendingRequirementVO;
import com.songlin.bidding.dto.QuoteEditVO;
import com.songlin.bidding.dto.QuotationQuery;
import com.songlin.bidding.dto.QuotationSaveRequest;
import com.songlin.bidding.dto.QuotationVO;
import com.songlin.bidding.service.QuotationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 供应商报价接口
 */
@Tag(name = "供应商报价", description = "我的报价列表、待报价需求、报价编辑数据、报价详情、提交报价（数据按当前供应商隔离）")
@RestController
@RequestMapping("/api/quotations")
@RequiredArgsConstructor
public class QuotationController {

  private final QuotationService quotationService;

  @Operation(summary = "我的历史报价单据", description = "仅返回当前登录供应商的报价；条件：reqNo / quoteNo / status / quoteStart / quoteEnd")
  @GetMapping
  public Result<PageResult<QuotationVO>> myPage(
      @Parameter(description = "查询条件与分页参数") QuotationQuery query) {
    return Result.success(quotationService.myPage(query));
  }

  @Operation(summary = "待报价需求", description = "未截止且未中标的需求，myQuote 标识当前用户是否已报价")
  @GetMapping("/pending-list")
  public Result<List<PendingRequirementVO>> pendingList() {
    return Result.success(quotationService.pendingList());
  }

  @Operation(summary = "报价编辑页数据", description = "上游需求只读信息 + 本人已报价内容回填；未报价时报价单号为预生成值")
  @GetMapping("/edit-data")
  public Result<QuoteEditVO> editData(
      @Parameter(description = "需求 ID", required = true) Long requirementId) {
    return Result.success(quotationService.editData(requirementId));
  }

  @Operation(summary = "报价单详情", description = "含商品报价明细")
  @GetMapping("/{id}")
  public Result<QuotationVO> detail(
      @Parameter(description = "报价单 ID", required = true) @PathVariable Long id) {
    return Result.success(quotationService.detail(id));
  }

  @Operation(summary = "提交报价", description = "截止前可多次提交覆盖（同一需求 + 同一报价人仅一份报价单）；截止后禁止提交")
  @PostMapping
  public Result<Long> submit(@Valid @RequestBody QuotationSaveRequest request) {
    return Result.success(quotationService.submit(request));
  }
}
