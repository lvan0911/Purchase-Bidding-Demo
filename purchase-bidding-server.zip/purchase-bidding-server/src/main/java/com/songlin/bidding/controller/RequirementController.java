package com.songlin.bidding.controller;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.Result;
import com.songlin.bidding.dto.RequirementQuery;
import com.songlin.bidding.dto.RequirementSaveRequest;
import com.songlin.bidding.dto.RequirementVO;
import com.songlin.bidding.service.RequirementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 采购需求接口
 */
@Tag(name = "采购需求", description = "需求单的分页查询、详情、单号预生成、发布保存；采购员仅能查看本人创建的需求")
@RestController
@RequestMapping("/api/requirements")
@RequiredArgsConstructor
public class RequirementController {

  private final RequirementService requirementService;

  @Operation(summary = "需求分页查询", description = "条件：reqNo / keyword（配件图号或名称）/ deadlineStart / deadlineEnd / status（quoting|expired）；中标的需求也归为已截止")
  @GetMapping
  public Result<PageResult<RequirementVO>> page(
      @Parameter(description = "查询条件与分页参数") RequirementQuery query) {
    return Result.success(requirementService.page(query));
  }

  @Operation(summary = "需求详情", description = "含商品清单")
  @GetMapping("/{id}")
  public Result<RequirementVO> detail(
      @Parameter(description = "需求 ID", required = true) @PathVariable Long id) {
    return Result.success(requirementService.detail(id));
  }

  @Operation(summary = "预生成需求单号", description = "仅用于新增页展示，正式单号在保存时由服务端生成")
  @GetMapping("/next-no")
  public Result<String> nextNo() {
    return Result.success(requirementService.nextReqNo());
  }

  @Operation(summary = "发布 / 保存采购需求", description = "id 为空为新增，否则为编辑；保存后该需求的历史报价与中标记录会被清空")
  @PostMapping
  public Result<Long> publish(@Valid @RequestBody RequirementSaveRequest request) {
    return Result.success(requirementService.publish(request));
  }
}
