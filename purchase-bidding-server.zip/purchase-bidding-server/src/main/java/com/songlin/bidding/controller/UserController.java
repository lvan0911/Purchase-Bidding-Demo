package com.songlin.bidding.controller;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.Result;
import com.songlin.bidding.dto.UserAccountVO;
import com.songlin.bidding.dto.UserQuery;
import com.songlin.bidding.dto.UserSaveRequest;
import com.songlin.bidding.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户管理接口
 */
@Tag(name = "用户管理", description = "用户的分页查询、新增、编辑、删除，以及手机号占用校验")
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

  private final UserService userService;

  @Operation(summary = "用户分页查询", description = "支持按用户名、手机号、姓名、角色、状态组合查询")
  @GetMapping
  public Result<PageResult<UserAccountVO>> page(
      @Parameter(description = "查询条件：username / phone / name / role / enabled / pageNum / pageSize")
      UserQuery query) {
    return Result.success(userService.page(query));
  }

  @Operation(summary = "新增用户", description = "username 选填，不传时默认使用手机号；password 选填，默认 123456")
  @PostMapping
  public Result<Long> save(@Valid @RequestBody UserSaveRequest request) {
    request.setId(null);
    return Result.success(userService.save(request));
  }

  @Operation(summary = "编辑用户", description = "密码字段为空表示不修改密码")
  @PutMapping("/{id}")
  public Result<Long> update(
      @Parameter(description = "用户 ID", required = true) @PathVariable Long id,
      @Valid @RequestBody UserSaveRequest request) {
    request.setId(id);
    return Result.success(userService.save(request));
  }

  @Operation(summary = "删除用户", description = "逻辑删除；不能删除当前登录账号")
  @DeleteMapping("/{id}")
  public Result<Void> delete(
      @Parameter(description = "用户 ID", required = true) @PathVariable Long id) {
    userService.delete(id);
    return Result.success();
  }

  @Operation(summary = "手机号是否已被占用", description = "excludeId 用于编辑时排除自身")
  @GetMapping("/phone-exists")
  public Result<Boolean> phoneExists(
      @Parameter(description = "手机号") String phone,
      @Parameter(description = "排除的用户 ID") Long excludeId) {
    return Result.success(userService.phoneExists(phone, excludeId));
  }
}
