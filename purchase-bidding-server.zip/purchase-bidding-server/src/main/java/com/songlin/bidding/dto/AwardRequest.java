package com.songlin.bidding.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

/**
 * 确认中标请求（支持批量）
 */
@Data
public class AwardRequest {

  /** 待确认中标的报价单 ID 列表 */
  @NotEmpty(message = "请选择要确认中标的报价单")
  private List<Long> quotationIds;

  /**
   * 单个确认时的便捷字段（选填，服务端会合并进 quotationIds），
   * 保留用于兼容旧调用方
   */
  private Long quotationId;
}
