package com.songlin.bidding.dto;

import lombok.Data;

/**
 * 分页查询基类
 */
@Data
public class BasePageQuery {

  private int pageNum = 1;
  private int pageSize = 10;

  /** MyBatis limit offset */
  public int getOffset() {
    if (pageNum < 1) {
      pageNum = 1;
    }
    if (pageSize < 1) {
      pageSize = 10;
    }
    return (pageNum - 1) * pageSize;
  }
}
