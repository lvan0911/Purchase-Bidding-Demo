package com.songlin.bidding.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 排名及采购确认查询条件
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ConfirmQuery extends BasePageQuery {

  /** 需求单号（模糊） */
  private String reqNo;
  /** 报价单号（模糊） */
  private String quoteNo;
  /** 供应商名称/报价人（模糊） */
  private String supplier;
  /** 状态（中标状态）：pending-待确认 / awarded-已中标 / lost-未中标 */
  private String status;

  /* 以下由服务端按当前登录用户填充，前端不传 */

  /** 限制创建人（采购员只看本人创建需求的报价） */
  private String creatorFilter;
  /** 限制报价人 ID（供应商只看本人的报价） */
  private Long quoteUserId;
  /** 限制报价人（供应商只看本人的报价，按用户名兼容） */
  private String quotePerson;
}
