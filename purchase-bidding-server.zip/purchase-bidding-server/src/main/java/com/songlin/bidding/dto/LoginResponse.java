package com.songlin.bidding.dto;

import lombok.Data;

/**
 * 登录返回：token + 当前登录用户信息
 */
@Data
public class LoginResponse {

  private String token;
  private Long userId;
  private String username;
  private String name;
  private String role;
  private String phone;
  private String company;
}
