package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 待报价需求（供应商视角）
 */
@Data
public class PendingRequirementVO {

  private Long id;
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  /** 商品数量 */
  private Integer itemCount;
  /** 当前供应商是否已报价 */
  private Boolean myQuote;
}
