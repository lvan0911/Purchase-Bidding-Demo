package com.songlin.bidding.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 报价单查询条件（供应商"我的报价"列表）
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class QuotationQuery extends BasePageQuery {

  /** 需求单号（模糊） */
  private String reqNo;
  /** 报价单号（模糊） */
  private String quoteNo;
  /** 状态（中标状态）：quoting-报价中 / pending-待确认 / awarded-已中标 / lost-未中标 */
  private String status;
  /** 报价时间起 yyyy-MM-dd */
  private String quoteStart;
  /** 报价时间止 yyyy-MM-dd */
  private String quoteEnd;

  /* 以下由服务端按当前登录用户填充，前端不传 */

  /** 报价人（当前登录用户姓名/账号） */
  private String quotePerson;
  /** 当前登录用户 ID */
  private Long quoteUserId;
}
