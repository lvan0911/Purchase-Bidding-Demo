package com.songlin.bidding.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 提交报价请求
 */
@Data
public class QuotationSaveRequest {

  @NotNull(message = "缺少需求单参数")
  private Long requirementId;

  @NotBlank(message = "请选择确定交货日期")
  private String confirmDeliverDate;

  @NotBlank(message = "请输入报价人")
  private String quotePerson;

  /** 报价单整体备注 */
  private String quoteRemark;

  @Valid
  @NotEmpty(message = "报价商品不能为空")
  private List<Item> items;

  @Data
  public static class Item {
    @NotNull(message = "报价商品行缺少需求商品 ID")
    private Long requirementItemId;

    @NotNull(message = "请填写单价")
    private BigDecimal unitPrice;

    /** 该行报价备注 */
    private String quoteRemark;
  }
}
