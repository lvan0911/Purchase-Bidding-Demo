package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 报价单详情（含商品报价明细）
 */
@Data
public class QuotationVO {

  private Long id;
  private String quoteNo;
  private Long requirementId;
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate confirmDeliverDate;

  private String quotePerson;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteTime;

  private String modifier;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime modifyTime;

  private String remark;
  private String quoteRemark;
  private BigDecimal totalAmount;
  /** 是否已截止 */
  private Boolean expired;
  /** 状态：quoting-报价中 / pending-待确认 / awarded-已中标 */
  private String status;
  /** 排名（截止后有效，截止前为 null） */
  private Integer rank;
  /** 中标状态：0-待确认 1-已中标 2-未中标 */
  private Integer awardStatus;
  /** 中标供应商名称（需求单已确认中标时返回，对应 award_result.supplier_name） */
  private String awardedSupplierName;
  /** 报价供应商公司名称（sys_user.company，依据 quote_user_id 解析） */
  private String supplierName;
  /** 报价人用户ID（用于解析公司名称） */
  private Long quoteUserId;

  private List<QuoteItemVO> items;
}
