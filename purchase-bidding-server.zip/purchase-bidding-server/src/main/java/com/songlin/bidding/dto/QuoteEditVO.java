package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 报价编辑页数据：上游需求信息（只读）+ 本人已报价信息（回填）
 */
@Data
public class QuoteEditVO {

  private Long requirementId;
  /** 本次编辑的报价单 ID；未报价（首次进入）时为 null */
  private Long quotationId;
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  private String remark;

  /** 报价单号：已报价时回填原单号，否则为新生成的单号 */
  private String quoteNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteTime;

  private String modifier;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime modifyTime;

  /** 确定交货日期（已报价时回填） */
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate confirmDeliverDate;

  /** 报价人，默认当前登录用户 */
  private String quotePerson;

  private String quoteRemark;

  /** 原报价合计金额（已报价时回填） */
  private java.math.BigDecimal totalAmount;

  /** 是否已截止：截止后禁止提交/修改 */
  private Boolean expired;

  private List<QuoteItemVO> items;
}
