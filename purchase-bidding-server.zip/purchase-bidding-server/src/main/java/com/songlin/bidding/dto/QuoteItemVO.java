package com.songlin.bidding.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 报价商品行（与前端 QuoteItem 对齐）
 */
@Data
public class QuoteItemVO {

  private Long id;
  private Long requirementItemId;
  private String partNo;
  private String replaceNo;
  private String partName;
  private Integer quantity;
  /** 单价 */
  private BigDecimal unitPrice;
  private String unit;
  private String spec;
  private String purchaseRemark;
  /** 该行报价备注 */
  private String quoteRemark;
}
