package com.songlin.bidding.dto;

import lombok.Data;

/**
 * 需求商品行（与前端 RequirementItem 对齐）
 */
@Data
public class RequirementItemVO {

  private Long id;
  private String partNo;
  private String replaceNo;
  private String partName;
  private Integer quantity;
  private String unit;
  private String spec;
  private String purchaseRemark;
  /** 是否已发布（发布后不可编辑） */
  private Boolean published;
}
