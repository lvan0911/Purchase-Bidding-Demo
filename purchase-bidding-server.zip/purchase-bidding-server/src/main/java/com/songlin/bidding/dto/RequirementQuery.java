package com.songlin.bidding.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 采购需求列表查询条件
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RequirementQuery extends BasePageQuery {

  /** 需求单号（模糊） */
  private String reqNo;
  /** 配件关键字：配件图号 / 配件名称（模糊） */
  private String keyword;
  /** 报价截止日期起 yyyy-MM-dd */
  private String deadlineStart;
  /** 报价截止日期止 yyyy-MM-dd */
  private String deadlineEnd;
  /** 状态：quoting-报价中 / expired-已截止（中标的需求也归为已截止） */
  private String status;

  /* 以下由服务端按当前登录用户填充，前端不传 */

  /** 限制创建人（采购员只看本人创建的） */
  private String creatorFilter;
}
