package com.songlin.bidding.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

/**
 * 采购需求保存（发布）请求
 */
@Data
public class RequirementSaveRequest {

  /** 为空表示新增，否则为编辑 */
  private Long id;
  /** 需求单号：新增时后端按规则生成 */
  private String reqNo;

  @NotBlank(message = "请选择报价截止日期")
  private String quoteDeadline;

  @NotBlank(message = "请选择集中交货日期")
  private String deliverDate;

  private String remark;

  @Valid
  @NotEmpty(message = "请至少新增一条商品")
  private List<Item> items;

  @Data
  public static class Item {
    private Long id;

    @NotBlank(message = "请输入配件图号")
    private String partNo;

    private String replaceNo;

    @NotBlank(message = "请输入配件名称")
    private String partName;

    @NotNull(message = "请输入采购数量")
    private Integer quantity;

    private String unit;
    private String spec;
    private String purchaseRemark;
  }
}
