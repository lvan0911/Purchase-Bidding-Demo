package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 采购需求详情（含商品清单）
 */
@Data
public class RequirementVO {

  private Long id;
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  private String creator;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;

  private String modifier;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime modifyTime;

  private String remark;
  /** 商品数量 */
  private Integer itemCount;
  /** 状态：quoting / expired / awarded */
  private String status;

  private List<RequirementItemVO> items;
}
