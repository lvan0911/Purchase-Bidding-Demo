package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户管理列表行（与前端 UserAccount 对齐）
 */
@Data
public class UserAccountVO {

  private Long id;
  /** 登录账号 */
  private String username;
  /** 账号（手机号） */
  private String phone;
  private String name;
  private String email;
  private String company;
  /** admin / purchaser / supplier */
  private String role;
  /** 1-启用 0-禁用 */
  private Boolean enabled;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;
}
