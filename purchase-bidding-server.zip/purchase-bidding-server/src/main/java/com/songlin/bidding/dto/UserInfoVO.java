package com.songlin.bidding.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 当前登录用户信息
 */
@Data
public class UserInfoVO {

  private Long id;
  private String username;
  private String name;
  private String phone;
  private String email;
  private String company;
  private String role;
  private Integer enabled;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;
}
