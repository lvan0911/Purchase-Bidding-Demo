package com.songlin.bidding.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 用户管理查询条件
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UserQuery extends BasePageQuery {

  /** 用户名（模糊） */
  private String username;
  /** 手机号（模糊） */
  private String phone;
  /** 姓名（模糊） */
  private String name;
  /** 角色：admin / purchaser / supplier */
  private String role;
  /** 状态：1-启用 0-禁用 */
  private Integer enabled;
}
