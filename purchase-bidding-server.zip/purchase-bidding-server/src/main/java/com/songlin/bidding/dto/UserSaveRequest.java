package com.songlin.bidding.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * 用户新增 / 编辑请求
 */
@Data
public class UserSaveRequest {

  /** 为空表示新增，否则为编辑 */
  private Long id;

  /** 登录账号：不传时默认使用手机号 */
  private String username;

  @NotBlank(message = "请输入账号（手机号）")
  @Pattern(regexp = "^1\\d{10}$", message = "请输入正确的 11 位手机号")
  private String phone;

  @NotBlank(message = "请输入姓名")
  private String name;

  @NotBlank(message = "请输入邮箱")
  @Email(message = "邮箱格式不正确")
  private String email;

  @NotBlank(message = "请输入公司名称")
  private String company;

  @NotBlank(message = "请选择角色")
  @Pattern(regexp = "admin|purchaser|supplier", message = "角色取值非法")
  private String role;

  @NotNull(message = "请选择状态")
  private Boolean enabled;

  /** 新增/重置密码时使用，选填 */
  private String password;
}
