package com.songlin.bidding.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 中标结果（award_result）
 */
@Data
public class AwardResult {

  private Long id;
  private Long requirementId;
  private String reqNo;
  private Long quotationId;
  private String quoteNo;
  /** 中标供应商（报价人） */
  private String supplierName;
  /** 中标价格 */
  private BigDecimal awardPrice;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate confirmDeliverDate;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime confirmTime;

  private String operator;
  /** 1-已确认 */
  private Integer confirmed;
}
