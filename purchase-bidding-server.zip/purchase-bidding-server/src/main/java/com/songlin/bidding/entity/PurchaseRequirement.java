package com.songlin.bidding.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 采购需求单（purchase_requirement）
 */
@Data
public class PurchaseRequirement {

  private Long id;
  /** 需求单号 XQ + yyyyMMdd + 4位序号 */
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  private String creator;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;

  private String modifier;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime modifyTime;

  private String remark;
  private Integer deleted;
}
