package com.songlin.bidding.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 供应商报价单（quotation）
 */
@Data
public class Quotation {

  private Long id;
  /** 报价单号 BJ + yyyyMMdd + 4位序号 */
  private String quoteNo;
  private Long requirementId;
  /** 需求单号（冗余上游） */
  private String reqNo;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteDeadline;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate deliverDate;

  /** 确定交货日期（报价方填写） */
  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate confirmDeliverDate;

  /** 报价人 */
  private String quotePerson;
  private Long quoteUserId;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime quoteTime;

  private String modifier;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime modifyTime;

  /** 备注（冗余上游） */
  private String remark;
  /** 报价备注（报价方填写） */
  private String quoteRemark;
  /** 合计金额 */
  private BigDecimal totalAmount;
  /** 中标状态：0-待确认 1-已中标 2-未中标 */
  private Integer awardStatus;
  private Integer deleted;
}
