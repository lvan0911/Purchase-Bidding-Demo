package com.songlin.bidding.entity;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 报价商品明细（quotation_item）
 */
@Data
public class QuotationItem {

  private Long id;
  private Long quotationId;
  private Long requirementItemId;
  private String partNo;
  private String replaceNo;
  private String partName;
  private Integer quantity;
  private String unit;
  private String spec;
  private String purchaseRemark;
  /** 单价（报价方填写） */
  private BigDecimal unitPrice;
  /** 该行报价备注 */
  private String quoteRemark;
  private Integer sortOrder;
}
