package com.songlin.bidding.entity;

import lombok.Data;

/**
 * 采购需求商品明细（requirement_item）
 */
@Data
public class RequirementItem {

  private Long id;
  private Long requirementId;
  /** 配件图号 */
  private String partNo;
  /** 通用/替换号 */
  private String replaceNo;
  /** 配件名称 */
  private String partName;
  /** 采购数量 */
  private Integer quantity;
  /** 单位 */
  private String unit;
  /** 规格型号 */
  private String spec;
  /** 采购备注 */
  private String purchaseRemark;
  /** 1-已发布（发布后不可编辑） */
  private Integer published;
  private Integer sortOrder;
  private Integer deleted;
}
