package com.songlin.bidding.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 系统用户（sys_user）
 */
@Data
public class SysUser {

  private Long id;
  private String username;
  private String password;
  /** 账号（手机号） */
  private String phone;
  private String name;
  private String email;
  private String company;
  /** admin / purchaser / supplier */
  private String role;
  /** 1-启用 0-禁用 */
  private Integer enabled;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime updateTime;

  private Integer deleted;
}
