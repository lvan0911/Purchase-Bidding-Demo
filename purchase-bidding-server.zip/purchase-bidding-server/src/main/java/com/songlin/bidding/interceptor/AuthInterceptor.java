package com.songlin.bidding.interceptor;

import com.songlin.bidding.common.LoginUser;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.entity.SysUser;
import com.songlin.bidding.mapper.SysUserMapper;
import com.songlin.bidding.util.JwtUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 登录鉴权拦截器：校验 Authorization: Bearer &lt;token&gt;
 */
@Slf4j
@Component
public class AuthInterceptor implements HandlerInterceptor {

  private static final String HEADER = "Authorization";
  private static final String PREFIX = "Bearer ";

  private final JwtUtil jwtUtil;
  private final SysUserMapper sysUserMapper;

  public AuthInterceptor(JwtUtil jwtUtil, SysUserMapper sysUserMapper) {
    this.jwtUtil = jwtUtil;
    this.sysUserMapper = sysUserMapper;
  }

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
    if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
      return true;
    }
    String header = request.getHeader(HEADER);
    if (!StringUtils.hasText(header) || !header.startsWith(PREFIX)) {
      writeUnauthorized(response);
      return false;
    }
    String token = header.substring(PREFIX.length());
    Claims claims = jwtUtil.parse(token);
    if (claims == null) {
      writeUnauthorized(response);
      return false;
    }
    String username = claims.getSubject();
    SysUser user = sysUserMapper.selectByUsername(username);
    if (user == null || user.getDeleted() == 1 || Integer.valueOf(0).equals(user.getEnabled())) {
      writeUnauthorized(response);
      return false;
    }
    UserContext.set(LoginUser.of(user.getId(), user.getUsername(), user.getName(), user.getRole(), user.getCompany()));
    return true;
  }

  @Override
  public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                              Object handler, Exception ex) {
    UserContext.clear();
  }

  private void writeUnauthorized(HttpServletResponse response) {
    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    response.setContentType("application/json;charset=UTF-8");
    try {
      response.getWriter().write("{\"code\":401,\"message\":\"未登录或登录已过期\",\"data\":null}");
    } catch (Exception e) {
      log.debug("写入未登录响应失败", e);
    }
  }
}
