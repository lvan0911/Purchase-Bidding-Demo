package com.songlin.bidding.mapper;

import com.songlin.bidding.entity.AwardResult;
import org.apache.ibatis.annotations.Param;

/**
 * 中标结果 Mapper
 */
public interface AwardResultMapper {

  int insert(AwardResult award);

  int update(AwardResult award);

  AwardResult selectByRequirementId(@Param("requirementId") Long requirementId);

  AwardResult selectByQuotationId(@Param("quotationId") Long quotationId);

  int deleteByRequirementId(@Param("requirementId") Long requirementId);
}
