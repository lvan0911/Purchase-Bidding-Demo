package com.songlin.bidding.mapper;

import com.songlin.bidding.dto.RequirementQuery;
import com.songlin.bidding.dto.RequirementVO;
import com.songlin.bidding.entity.PurchaseRequirement;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 采购需求单 Mapper
 */
public interface PurchaseRequirementMapper {

  int insert(PurchaseRequirement requirement);

  int update(PurchaseRequirement requirement);

  int logicDelete(@Param("id") Long id);

  PurchaseRequirement selectById(@Param("id") Long id);

  PurchaseRequirement selectByReqNo(@Param("reqNo") String reqNo);

  /** 列表（含商品数量），按创建时间倒序 */
  List<RequirementVO> selectPage(RequirementQuery query);

  long countPage(RequirementQuery query);

  /** 生成单号用：查询当天（含前缀）最大单号 */
  String selectMaxNo(@Param("prefix") String prefix);
}
