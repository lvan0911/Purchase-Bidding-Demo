package com.songlin.bidding.mapper;

import com.songlin.bidding.entity.QuotationItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 报价商品明细 Mapper
 */
public interface QuotationItemMapper {

  int batchInsert(@Param("list") List<QuotationItem> list);

  int deleteByQuotationId(@Param("quotationId") Long quotationId);

  List<QuotationItem> selectByQuotationId(@Param("quotationId") Long quotationId);
}
