package com.songlin.bidding.mapper;

import com.songlin.bidding.dto.ConfirmQuery;
import com.songlin.bidding.dto.PendingRequirementVO;
import com.songlin.bidding.dto.QuotationQuery;
import com.songlin.bidding.dto.QuotationVO;
import com.songlin.bidding.entity.Quotation;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 报价单 Mapper
 */
public interface QuotationMapper {

  int insert(Quotation quotation);

  int update(Quotation quotation);

  int logicDelete(@Param("id") Long id);

  Quotation selectById(@Param("id") Long id);

  /** 同一需求 + 同一报价人 的报价单（用于多次编辑回填） */
  Quotation selectByRequirementAndPerson(@Param("requirementId") Long requirementId,
                                         @Param("quotePerson") String quotePerson);

  /** 同一需求 + 同一供应商用户 的报价单（按用户 ID 精确匹配，优先用于回填/重提交） */
  Quotation selectByRequirementAndUserId(@Param("requirementId") Long requirementId,
                                         @Param("quoteUserId") Long quoteUserId);

  /** 某需求的全部报价单（用于排名计算） */
  List<Quotation> selectByRequirementId(@Param("requirementId") Long requirementId);

  /** 我的报价列表 */
  List<QuotationVO> selectMyPage(QuotationQuery query);

  long countMyPage(QuotationQuery query);

  /** 排名及采购确认列表 */
  List<QuotationVO> selectConfirmPage(ConfirmQuery query);

  long countConfirmPage(ConfirmQuery query);

  /** 待报价需求（未截止且未中标） */
  List<PendingRequirementVO> selectPendingList(@Param("quotePerson") String quotePerson);

  /** 重新发布需求时清空该需求的历史报价 */
  int logicDeleteByRequirementId(@Param("requirementId") Long requirementId);

  /** 将指定报价单设为某一中标状态 */
  int updateAwardStatusById(@Param("id") Long id, @Param("awardStatus") Integer awardStatus);

  /** 将某需求下（除指定报价单外）的全部报价单设为某一中标状态，用于批量标记未中标 */
  int updateAwardStatusByRequirement(@Param("requirementId") Long requirementId,
                                     @Param("awardStatus") Integer awardStatus,
                                     @Param("excludeQuotationId") Long excludeQuotationId);

  /** 生成单号用：查询当天（含前缀）最大单号 */
  String selectMaxNo(@Param("prefix") String prefix);
}
