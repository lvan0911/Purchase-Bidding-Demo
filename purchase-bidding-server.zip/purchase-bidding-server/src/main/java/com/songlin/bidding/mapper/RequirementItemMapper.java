package com.songlin.bidding.mapper;

import com.songlin.bidding.entity.RequirementItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 需求商品明细 Mapper
 */
public interface RequirementItemMapper {

  int insert(RequirementItem item);

  int update(RequirementItem item);

  int logicDelete(@Param("id") Long id);

  List<RequirementItem> selectByRequirementId(@Param("requirementId") Long requirementId);

  int selectMaxSortOrder(@Param("requirementId") Long requirementId);
}
