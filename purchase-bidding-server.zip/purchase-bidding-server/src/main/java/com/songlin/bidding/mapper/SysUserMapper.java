package com.songlin.bidding.mapper;

import com.songlin.bidding.dto.UserAccountVO;
import com.songlin.bidding.dto.UserQuery;
import com.songlin.bidding.entity.SysUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 系统用户 Mapper
 */
public interface SysUserMapper {

  int insert(SysUser user);

  int update(SysUser user);

  /** 逻辑删除 */
  int logicDelete(@Param("id") Long id);

  SysUser selectById(@Param("id") Long id);

  SysUser selectByUsername(@Param("username") String username);

  /** 按用户名或手机号查询（用于登录） */
  SysUser selectByUsernameOrPhone(@Param("account") String account);

  long countAll();

  /** 手机号是否已被占用（排除指定 id） */
  long countByPhone(@Param("phone") String phone, @Param("excludeId") Long excludeId);

  /** 账号是否已被占用（排除指定 id） */
  long countByUsername(@Param("username") String username, @Param("excludeId") Long excludeId);

  List<UserAccountVO> selectPage(UserQuery query);

  long countPage(UserQuery query);
}
