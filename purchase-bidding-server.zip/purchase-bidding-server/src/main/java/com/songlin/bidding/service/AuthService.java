package com.songlin.bidding.service;

import com.songlin.bidding.dto.LoginRequest;
import com.songlin.bidding.dto.LoginResponse;
import com.songlin.bidding.dto.UserInfoVO;

/**
 * 登录认证
 */
public interface AuthService {

  /** 登录：校验账号密码，返回 token 与用户信息 */
  LoginResponse login(LoginRequest request);

  /** 获取当前登录用户信息 */
  UserInfoVO currentUser();
}
