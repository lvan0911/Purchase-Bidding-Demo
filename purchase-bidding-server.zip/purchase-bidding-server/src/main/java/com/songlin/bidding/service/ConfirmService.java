package com.songlin.bidding.service;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.dto.AwardRequest;
import com.songlin.bidding.dto.ConfirmQuery;
import com.songlin.bidding.dto.QuotationVO;

/**
 * 排名及采购确认
 */
public interface ConfirmService {

  /** 报价单列表：含排名与状态（报价中不排名、采购方不可见金额） */
  PageResult<QuotationVO> page(ConfirmQuery query);

  /** 报价单详情：含商品报价明细、排名与状态 */
  QuotationVO detail(Long quotationId);

  /**
   * 批量确认中标
   *
   * @param request 报价单 ID 列表
   * @return 成功确认的条数
   */
  int award(AwardRequest request);
}
