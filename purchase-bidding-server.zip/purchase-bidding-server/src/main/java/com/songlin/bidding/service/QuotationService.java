package com.songlin.bidding.service;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.dto.PendingRequirementVO;
import com.songlin.bidding.dto.QuoteEditVO;
import com.songlin.bidding.dto.QuotationQuery;
import com.songlin.bidding.dto.QuotationSaveRequest;
import com.songlin.bidding.dto.QuotationVO;

import java.util.List;

/**
 * 供应商报价
 */
public interface QuotationService {

  /** 我的历史报价单据（仅本人） */
  PageResult<QuotationVO> myPage(QuotationQuery query);

  /** 待报价需求：未截止且未中标 */
  List<PendingRequirementVO> pendingList();

  /** 报价编辑页数据：上游需求只读信息 + 本人已报价内容回填 */
  QuoteEditVO editData(Long requirementId);

  /** 提交报价：截止前可多次提交覆盖（同一需求 + 同一报价人一份报价单） */
  Long submit(QuotationSaveRequest request);

  /** 报价单详情（含商品报价明细） */
  QuotationVO detail(Long id);
}
