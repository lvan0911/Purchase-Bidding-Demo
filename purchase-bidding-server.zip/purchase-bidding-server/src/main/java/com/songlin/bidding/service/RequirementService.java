package com.songlin.bidding.service;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.dto.RequirementQuery;
import com.songlin.bidding.dto.RequirementSaveRequest;
import com.songlin.bidding.dto.RequirementVO;

/**
 * 采购需求
 */
public interface RequirementService {

  /** 分页查询（含商品数量与状态） */
  PageResult<RequirementVO> page(RequirementQuery query);

  /** 详情（含商品清单） */
  RequirementVO detail(Long id);

  /** 预生成需求单号：XQ + yyyyMMdd + 4位序号 */
  String nextReqNo();

  /**
   * 发布/保存需求单：保存基础信息与商品清单，
   * 并清空该需求的历史报价与中标记录，保证 需求 -&gt; 报价 -&gt; 排名确认 的数据串联完整
   */
  Long publish(RequirementSaveRequest request);
}
