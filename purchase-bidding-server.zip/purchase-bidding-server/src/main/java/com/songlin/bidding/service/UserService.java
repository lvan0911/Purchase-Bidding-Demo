package com.songlin.bidding.service;

import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.dto.UserAccountVO;
import com.songlin.bidding.dto.UserQuery;
import com.songlin.bidding.dto.UserSaveRequest;

/**
 * 用户管理
 */
public interface UserService {

  /** 分页查询 */
  PageResult<UserAccountVO> page(UserQuery query);

  /** 新增或编辑，返回用户 ID */
  Long save(UserSaveRequest request);

  /** 删除（逻辑删除） */
  void delete(Long id);

  /** 手机号是否已被占用（excludeId 为编辑时排除的自身 ID） */
  boolean phoneExists(String phone, Long excludeId);
}
