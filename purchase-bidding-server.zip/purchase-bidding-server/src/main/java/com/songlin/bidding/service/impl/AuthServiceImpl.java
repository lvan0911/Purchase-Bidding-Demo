package com.songlin.bidding.service.impl;

import com.songlin.bidding.common.BusinessException;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.dto.LoginRequest;
import com.songlin.bidding.dto.LoginResponse;
import com.songlin.bidding.dto.UserInfoVO;
import com.songlin.bidding.entity.SysUser;
import com.songlin.bidding.mapper.SysUserMapper;
import com.songlin.bidding.service.AuthService;
import com.songlin.bidding.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * 登录认证实现
 */
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

  private final SysUserMapper sysUserMapper;
  private final PasswordEncoder passwordEncoder;
  private final JwtUtil jwtUtil;

  @Override
  public LoginResponse login(LoginRequest request) {
    String account = request.getUsername().trim();
    SysUser user = sysUserMapper.selectByUsernameOrPhone(account);
    if (user == null) {
      throw new BusinessException(401, "用户名或密码错误");
    }
    if (Integer.valueOf(0).equals(user.getEnabled())) {
      throw new BusinessException(401, "账号已禁用，请联系管理员");
    }
    if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
      throw new BusinessException(401, "用户名或密码错误");
    }
    String token = jwtUtil.generateToken(user.getId(), user.getUsername());

    LoginResponse resp = new LoginResponse();
    resp.setToken(token);
    resp.setUserId(user.getId());
    resp.setUsername(user.getUsername());
    resp.setName(user.getName());
    resp.setRole(user.getRole());
    resp.setPhone(user.getPhone());
    resp.setCompany(user.getCompany());
    return resp;
  }

  @Override
  public UserInfoVO currentUser() {
    Long userId = UserContext.currentUserId();
    if (userId == null) {
      throw new BusinessException(401, "未登录");
    }
    SysUser user = sysUserMapper.selectById(userId);
    if (user == null) {
      throw new BusinessException(401, "登录用户不存在");
    }
    UserInfoVO vo = new UserInfoVO();
    vo.setId(user.getId());
    vo.setUsername(user.getUsername());
    vo.setName(user.getName());
    vo.setPhone(user.getPhone());
    vo.setEmail(user.getEmail());
    vo.setCompany(user.getCompany());
    vo.setRole(user.getRole());
    vo.setEnabled(user.getEnabled());
    vo.setCreateTime(user.getCreateTime());
    return vo;
  }
}
