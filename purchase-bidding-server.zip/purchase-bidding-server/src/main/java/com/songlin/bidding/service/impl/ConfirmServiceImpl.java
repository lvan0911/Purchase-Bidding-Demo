package com.songlin.bidding.service.impl;

import com.songlin.bidding.common.BusinessException;
import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.dto.AwardRequest;
import com.songlin.bidding.dto.ConfirmQuery;
import com.songlin.bidding.dto.QuoteItemVO;
import com.songlin.bidding.dto.QuotationVO;
import com.songlin.bidding.entity.AwardResult;
import com.songlin.bidding.entity.Quotation;
import com.songlin.bidding.entity.QuotationItem;
import com.songlin.bidding.mapper.AwardResultMapper;
import com.songlin.bidding.mapper.QuotationItemMapper;
import com.songlin.bidding.mapper.QuotationMapper;
import com.songlin.bidding.mapper.SysUserMapper;
import com.songlin.bidding.service.ConfirmService;
import com.songlin.bidding.service.support.RankSupport;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 排名及采购确认实现
 */
@Service
@RequiredArgsConstructor
public class ConfirmServiceImpl implements ConfirmService {

  private final QuotationMapper quotationMapper;
  private final QuotationItemMapper quotationItemMapper;
  private final AwardResultMapper awardResultMapper;
  private final SysUserMapper sysUserMapper;
  private final RankSupport rankSupport;

  @Override
  public PageResult<QuotationVO> page(ConfirmQuery query) {
    applyScopeFilter(query);
    List<QuotationVO> list = quotationMapper.selectConfirmPage(query);
    long total = quotationMapper.countConfirmPage(query);
    fillStatusAndRank(list);
    return PageResult.of(list, total, query.getPageNum(), query.getPageSize());
  }

  /**
   * 按角色设置数据隔离：
   *  - admin：所有
   *  - purchaser：本人创建需求的全部报价
   *  - supplier：本人提交的报价
   */
  private void applyScopeFilter(ConfirmQuery query) {
    if (UserContext.isAdmin()) {
      query.setCreatorFilter(null);
      query.setQuoteUserId(null);
      query.setQuotePerson(null);
    } else if (UserContext.isPurchaser()) {
      query.setCreatorFilter(UserContext.currentName());
      query.setQuoteUserId(null);
      query.setQuotePerson(null);
    } else if (UserContext.isSupplier()) {
      query.setCreatorFilter(null);
      query.setQuoteUserId(UserContext.currentUserId());
      query.setQuotePerson(UserContext.currentName());
    }
  }

  @Override
  public QuotationVO detail(Long quotationId) {
    Quotation q = quotationMapper.selectById(quotationId);
    if (q == null || Integer.valueOf(1).equals(q.getDeleted())) {
      throw new BusinessException("报价单不存在或已被删除");
    }
    QuotationVO vo = toVO(q);
    fillStatusAndRank(Collections.singletonList(vo));
    return vo;
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public int award(AwardRequest request) {
    List<Long> ids = resolveIds(request);
    if (ids.isEmpty()) {
      throw new BusinessException("请选择要确认中标的报价单");
    }

    // 1. 查询并逐个校验；同一需求单只能确认一个中标报价单
    List<Quotation> quotations = new ArrayList<>(ids.size());
    Set<Long> requirementIds = new HashSet<>();
    for (Long id : ids) {
      Quotation q = quotationMapper.selectById(id);
      if (q == null || Integer.valueOf(1).equals(q.getDeleted())) {
        throw new BusinessException("报价单不存在或已被删除：" + id);
      }
      if (q.getQuoteDeadline() != null && q.getQuoteDeadline().isAfter(LocalDateTime.now())) {
        throw new BusinessException("报价单【" + q.getQuoteNo() + "】报价尚未截止，暂不能确认中标");
      }
      if (!requirementIds.add(q.getRequirementId())) {
        throw new BusinessException("需求单【" + q.getReqNo() + "】只能确认一个中标报价单，请检查所选数据");
      }
      quotations.add(q);
    }

    // 2. 逐个确认（任一条校验失败则整批回滚）
    int count = 0;
    for (Quotation q : quotations) {
      awardOne(q);
      count++;
    }
    return count;
  }

  /** 合并并去重报价单 ID（兼容单个确认的 quotationId 字段） */
  private List<Long> resolveIds(AwardRequest request) {
    LinkedHashSet<Long> ids = new LinkedHashSet<>();
    if (request.getQuotationIds() != null) {
      for (Long id : request.getQuotationIds()) {
        if (id != null) {
          ids.add(id);
        }
      }
    }
    if (request.getQuotationId() != null) {
      ids.add(request.getQuotationId());
    }
    return new ArrayList<>(ids);
  }

  /** 中标状态：0-待确认 1-已中标 2-未中标 */
  private static final int AWARD_STATUS_AWARDED = 1;
  private static final int AWARD_STATUS_LOST = 2;

  /** 确认单个报价单中标：已存在记录则改判，不存在则新增 */
  private void awardOne(Quotation q) {
    AwardResult exist = awardResultMapper.selectByRequirementId(q.getRequirementId());
    if (exist != null && exist.getQuotationId() != null && exist.getQuotationId().equals(q.getId())) {
      throw new BusinessException("报价单【" + q.getQuoteNo() + "】已确认中标，请勿重复操作");
    }
    // 写入中标状态：同需求其余报价置为未中标，本报价置为已中标（兼容首次确认与改判）
    quotationMapper.updateAwardStatusByRequirement(q.getRequirementId(), AWARD_STATUS_LOST, q.getId());
    quotationMapper.updateAwardStatusById(q.getId(), AWARD_STATUS_AWARDED);
    if (exist == null) {
      AwardResult award = new AwardResult();
      award.setRequirementId(q.getRequirementId());
      award.setReqNo(q.getReqNo());
      award.setQuotationId(q.getId());
      award.setQuoteNo(q.getQuoteNo());
      award.setSupplierName(resolveSupplierName(q.getQuoteUserId(), q.getQuotePerson()));
      award.setAwardPrice(q.getTotalAmount());
      award.setConfirmDeliverDate(q.getConfirmDeliverDate());
      award.setConfirmTime(LocalDateTime.now());
      award.setOperator(UserContext.currentUsername());
      award.setConfirmed(1);
      awardResultMapper.insert(award);
    } else {
      // 改判中标供应商
      exist.setQuotationId(q.getId());
      exist.setQuoteNo(q.getQuoteNo());
      exist.setSupplierName(resolveSupplierName(q.getQuoteUserId(), q.getQuotePerson()));
      exist.setAwardPrice(q.getTotalAmount());
      exist.setConfirmDeliverDate(q.getConfirmDeliverDate());
      exist.setConfirmTime(LocalDateTime.now());
      exist.setOperator(UserContext.currentUsername());
      exist.setConfirmed(1);
      awardResultMapper.update(exist);
    }
  }

  /** 取供应商公司名称：优先 sys_user.company，缺省回退报价人 */
  private String resolveSupplierName(Long quoteUserId, String quotePerson) {
    if (quoteUserId != null) {
      com.songlin.bidding.entity.SysUser u = sysUserMapper.selectById(quoteUserId);
      if (u != null && u.getCompany() != null && !u.getCompany().isBlank()) {
        return u.getCompany();
      }
      if (u != null && u.getName() != null && !u.getName().isBlank()) {
        return u.getName();
      }
    }
    return quotePerson;
  }

  private QuotationVO toVO(Quotation q) {
    QuotationVO vo = new QuotationVO();
    vo.setId(q.getId());
    vo.setQuoteNo(q.getQuoteNo());
    vo.setRequirementId(q.getRequirementId());
    vo.setReqNo(q.getReqNo());
    vo.setQuoteDeadline(q.getQuoteDeadline());
    vo.setDeliverDate(q.getDeliverDate());
    vo.setConfirmDeliverDate(q.getConfirmDeliverDate());
    vo.setQuotePerson(q.getQuotePerson());
    vo.setQuoteUserId(q.getQuoteUserId());
    vo.setQuoteTime(q.getQuoteTime());
    vo.setModifier(q.getModifier());
    vo.setModifyTime(q.getModifyTime());
    vo.setRemark(q.getRemark());
    vo.setQuoteRemark(q.getQuoteRemark());
    vo.setTotalAmount(q.getTotalAmount());
    vo.setAwardStatus(q.getAwardStatus());

    List<QuoteItemVO> items = new ArrayList<>();
    for (QuotationItem item : quotationItemMapper.selectByQuotationId(q.getId())) {
      QuoteItemVO itemVO = new QuoteItemVO();
      itemVO.setId(item.getId());
      itemVO.setRequirementItemId(item.getRequirementItemId());
      itemVO.setPartNo(item.getPartNo());
      itemVO.setReplaceNo(item.getReplaceNo());
      itemVO.setPartName(item.getPartName());
      itemVO.setQuantity(item.getQuantity());
      itemVO.setUnitPrice(item.getUnitPrice());
      itemVO.setUnit(item.getUnit());
      itemVO.setSpec(item.getSpec());
      itemVO.setPurchaseRemark(item.getPurchaseRemark());
      itemVO.setQuoteRemark(item.getQuoteRemark());
      items.add(itemVO);
    }
    vo.setItems(items);
    return vo;
  }

  /** 状态（quoting / pending / awarded）与排名：截止前不排名 */
  private void fillStatusAndRank(List<QuotationVO> list) {
    if (list == null || list.isEmpty()) {
      return;
    }
    Set<Long> reqIds = new HashSet<>();
    for (QuotationVO vo : list) {
      reqIds.add(vo.getRequirementId());
    }
    Map<Long, AwardResult> awards = rankSupport.awardsOf(reqIds);
    Map<Long, Integer> ranks = rankSupport.ranksOf(reqIds);
    LocalDateTime now = LocalDateTime.now();
    for (QuotationVO vo : list) {
      boolean expired = vo.getQuoteDeadline() != null && vo.getQuoteDeadline().isBefore(now);
      vo.setExpired(expired);
      if (!expired) {
        vo.setStatus("quoting");
        vo.setRank(null);
        continue;
      }
      // 中标状态直接取自报价单持久化字段 award_status
      Integer awardStatus = vo.getAwardStatus();
      if (awardStatus != null && awardStatus == AWARD_STATUS_AWARDED) {
        vo.setStatus("awarded");
      } else if (awardStatus != null && awardStatus == AWARD_STATUS_LOST) {
        vo.setStatus("lost");
      } else {
        vo.setStatus("pending");
      }
      AwardResult award = awards.get(vo.getRequirementId());
      if (award != null) {
        vo.setAwardedSupplierName(award.getSupplierName());
      }
      vo.setSupplierName(resolveSupplierName(vo.getQuoteUserId(), vo.getQuotePerson()));
      vo.setRank(ranks.get(vo.getId()));
    }
  }
}
