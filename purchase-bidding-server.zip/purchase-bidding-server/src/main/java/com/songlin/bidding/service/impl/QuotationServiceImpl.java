package com.songlin.bidding.service.impl;

import com.songlin.bidding.common.BusinessException;
import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.dto.PendingRequirementVO;
import com.songlin.bidding.dto.QuoteEditVO;
import com.songlin.bidding.dto.QuoteItemVO;
import com.songlin.bidding.dto.QuotationQuery;
import com.songlin.bidding.dto.QuotationSaveRequest;
import com.songlin.bidding.dto.QuotationVO;
import com.songlin.bidding.entity.AwardResult;
import com.songlin.bidding.entity.PurchaseRequirement;
import com.songlin.bidding.entity.Quotation;
import com.songlin.bidding.entity.QuotationItem;
import com.songlin.bidding.entity.RequirementItem;
import com.songlin.bidding.mapper.PurchaseRequirementMapper;
import com.songlin.bidding.mapper.QuotationItemMapper;
import com.songlin.bidding.mapper.QuotationMapper;
import com.songlin.bidding.mapper.RequirementItemMapper;
import com.songlin.bidding.service.QuotationService;
import com.songlin.bidding.service.support.RankSupport;
import com.songlin.bidding.util.DateTimeUtil;
import com.songlin.bidding.util.NoGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 供应商报价实现
 */
@Service
@RequiredArgsConstructor
public class QuotationServiceImpl implements QuotationService {

  private final QuotationMapper quotationMapper;
  private final QuotationItemMapper quotationItemMapper;
  private final PurchaseRequirementMapper requirementMapper;
  private final RequirementItemMapper requirementItemMapper;
  private final RankSupport rankSupport;
  private final NoGenerator noGenerator;

  @Override
  public PageResult<QuotationVO> myPage(QuotationQuery query) {
    query.setQuoteUserId(UserContext.currentUserId());
    query.setQuotePerson(UserContext.currentUsername());
    List<QuotationVO> list = quotationMapper.selectMyPage(query);
    long total = quotationMapper.countMyPage(query);
    return PageResult.of(list, total, query.getPageNum(), query.getPageSize());
  }

  @Override
  public List<PendingRequirementVO> pendingList() {
    return quotationMapper.selectPendingList(UserContext.currentUsername());
  }

  @Override
  public QuoteEditVO editData(Long requirementId) {
    PurchaseRequirement req = requirementMapper.selectById(requirementId);
    if (req == null || Integer.valueOf(1).equals(req.getDeleted())) {
      throw new BusinessException("未找到对应的采购需求");
    }
    String quotePerson = UserContext.currentName();
    Quotation exist = findExistQuotation(requirementId, quotePerson);
    Map<Long, QuotationItem> existItems = new HashMap<>();
    if (exist != null) {
      for (QuotationItem item : quotationItemMapper.selectByQuotationId(exist.getId())) {
        existItems.put(item.getRequirementItemId(), item);
      }
    }

    QuoteEditVO vo = new QuoteEditVO();
    vo.setRequirementId(req.getId());
    vo.setQuotationId(exist != null ? exist.getId() : null);
    vo.setReqNo(req.getReqNo());
    vo.setQuoteDeadline(req.getQuoteDeadline());
    vo.setDeliverDate(req.getDeliverDate());
    vo.setRemark(req.getRemark());
    vo.setExpired(req.getQuoteDeadline() != null && req.getQuoteDeadline().isBefore(LocalDateTime.now()));
    vo.setQuotePerson(exist != null && exist.getQuotePerson() != null ? exist.getQuotePerson() : quotePerson);
    if (exist != null) {
      vo.setQuoteNo(exist.getQuoteNo());
      vo.setQuoteTime(exist.getQuoteTime());
      vo.setModifier(exist.getModifier());
      vo.setModifyTime(exist.getModifyTime());
      vo.setConfirmDeliverDate(exist.getConfirmDeliverDate());
      vo.setQuoteRemark(exist.getQuoteRemark());
      vo.setTotalAmount(exist.getTotalAmount());
    } else {
      vo.setQuoteNo(noGenerator.quoteNo());
      vo.setQuoteRemark("");
    }

    List<QuoteItemVO> items = new ArrayList<>();
    for (RequirementItem ri : requirementItemMapper.selectByRequirementId(requirementId)) {
      QuotationItem quoted = existItems.get(ri.getId());
      QuoteItemVO item = new QuoteItemVO();
      item.setId(quoted == null ? null : quoted.getId());
      item.setRequirementItemId(ri.getId());
      item.setPartNo(ri.getPartNo());
      item.setReplaceNo(ri.getReplaceNo());
      item.setPartName(ri.getPartName());
      item.setQuantity(ri.getQuantity());
      item.setUnit(ri.getUnit());
      item.setSpec(ri.getSpec());
      item.setPurchaseRemark(ri.getPurchaseRemark());
      item.setUnitPrice(quoted == null ? null : quoted.getUnitPrice());
      item.setQuoteRemark(quoted == null ? "" : quoted.getQuoteRemark());
      items.add(item);
    }
    vo.setItems(items);
    return vo;
  }

  /**
   * 查找某需求下当前供应商已有的报价单：优先按用户 ID（quote_user_id）精确匹配，
   * 兼容历史数据中 quote_user_id 为空的情况，回退到 quote_person（当前登录用户名）。
   */
  private Quotation findExistQuotation(Long requirementId, String quotePerson) {
    Long userId = UserContext.currentUserId();
    if (userId != null) {
      Quotation byUser = quotationMapper.selectByRequirementAndUserId(requirementId, userId);
      if (byUser != null) {
        return byUser;
      }
    }
    if (quotePerson != null && !quotePerson.isBlank()) {
      return quotationMapper.selectByRequirementAndPerson(requirementId, quotePerson);
    }
    return null;
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public Long submit(QuotationSaveRequest request) {
    PurchaseRequirement req = requirementMapper.selectById(request.getRequirementId());
    if (req == null || Integer.valueOf(1).equals(req.getDeleted())) {
      throw new BusinessException("未找到对应的采购需求");
    }
    if (req.getQuoteDeadline() != null && req.getQuoteDeadline().isBefore(LocalDateTime.now())) {
      throw new BusinessException("报价已截止，当前无法提交或修改报价");
    }
    if (isAwarded(req.getId())) {
      throw new BusinessException("该需求已完成中标确认，无法再报价");
    }

    LocalDate confirmDeliverDate = DateTimeUtil.parseDate(request.getConfirmDeliverDate());
    if (confirmDeliverDate == null) {
      throw new BusinessException("请选择确定交货日期");
    }
    if (request.getItems() == null || request.getItems().isEmpty()) {
      throw new BusinessException("报价商品不能为空");
    }

    Map<Long, RequirementItem> reqItems = new HashMap<>();
    for (RequirementItem ri : requirementItemMapper.selectByRequirementId(req.getId())) {
      reqItems.put(ri.getId(), ri);
    }

    BigDecimal total = BigDecimal.ZERO;
    List<QuotationItem> details = new ArrayList<>();
    int sort = 0;
    for (QuotationSaveRequest.Item item : request.getItems()) {
      RequirementItem ri = reqItems.get(item.getRequirementItemId());
      if (ri == null) {
        throw new BusinessException("报价商品与需求商品不匹配，请刷新后重试");
      }
      if (item.getUnitPrice() == null || item.getUnitPrice().compareTo(BigDecimal.ZERO) <= 0) {
        throw new BusinessException("商品【" + ri.getPartName() + "】未填写单价，或单价必须大于 0");
      }
      sort++;
      BigDecimal subtotal = item.getUnitPrice().multiply(BigDecimal.valueOf(ri.getQuantity()));
      total = total.add(subtotal);

      QuotationItem detail = new QuotationItem();
      detail.setRequirementItemId(ri.getId());
      detail.setPartNo(ri.getPartNo());
      detail.setReplaceNo(ri.getReplaceNo());
      detail.setPartName(ri.getPartName());
      detail.setQuantity(ri.getQuantity());
      detail.setUnit(ri.getUnit());
      detail.setSpec(ri.getSpec());
      detail.setPurchaseRemark(ri.getPurchaseRemark());
      detail.setUnitPrice(item.getUnitPrice());
      detail.setQuoteRemark(item.getQuoteRemark());
      detail.setSortOrder(sort);
      details.add(detail);
    }

    String quotePerson = UserContext.currentName();
    LocalDateTime now = LocalDateTime.now();
    Quotation exist = findExistQuotation(req.getId(), UserContext.currentUsername());

    if (exist == null) {
      Quotation q = new Quotation();
      q.setQuoteNo(noGenerator.quoteNo());
      q.setRequirementId(req.getId());
      q.setReqNo(req.getReqNo());
      q.setQuoteDeadline(req.getQuoteDeadline());
      q.setDeliverDate(req.getDeliverDate());
      q.setConfirmDeliverDate(confirmDeliverDate);
      q.setQuotePerson(quotePerson);
      q.setQuoteUserId(UserContext.currentUserId());
      q.setQuoteTime(now);
      q.setModifier(UserContext.currentUsername());
      q.setModifyTime(now);
      q.setRemark(req.getRemark());
      q.setQuoteRemark(request.getQuoteRemark());
      q.setTotalAmount(total);
      quotationMapper.insert(q);
      for (QuotationItem detail : details) {
        detail.setQuotationId(q.getId());
      }
      quotationItemMapper.batchInsert(details);
      return q.getId();
    }

    exist.setConfirmDeliverDate(confirmDeliverDate);
    exist.setQuoteRemark(request.getQuoteRemark());
    exist.setRemark(req.getRemark());
    exist.setQuoteDeadline(req.getQuoteDeadline());
    exist.setDeliverDate(req.getDeliverDate());
    exist.setTotalAmount(total);
    exist.setQuotePerson(quotePerson);
    exist.setModifier(UserContext.currentUsername());
    exist.setModifyTime(now);
    quotationMapper.update(exist);
    quotationItemMapper.deleteByQuotationId(exist.getId());
    for (QuotationItem detail : details) {
      detail.setQuotationId(exist.getId());
    }
    quotationItemMapper.batchInsert(details);
    return exist.getId();
  }

  @Override
  public QuotationVO detail(Long id) {
    Quotation q = quotationMapper.selectById(id);
    if (q == null || Integer.valueOf(1).equals(q.getDeleted())) {
      throw new BusinessException("报价单不存在或已被删除");
    }
    QuotationVO vo = toVO(q);
    fillStatusAndRank(Collections.singletonList(vo));
    return vo;
  }

  private boolean isAwarded(Long requirementId) {
    return rankSupport.awardsOf(Collections.singleton(requirementId)).containsKey(requirementId);
  }

  private QuotationVO toVO(Quotation q) {
    QuotationVO vo = new QuotationVO();
    vo.setId(q.getId());
    vo.setQuoteNo(q.getQuoteNo());
    vo.setRequirementId(q.getRequirementId());
    vo.setReqNo(q.getReqNo());
    vo.setQuoteDeadline(q.getQuoteDeadline());
    vo.setDeliverDate(q.getDeliverDate());
    vo.setConfirmDeliverDate(q.getConfirmDeliverDate());
    vo.setQuotePerson(q.getQuotePerson());
    vo.setQuoteTime(q.getQuoteTime());
    vo.setModifier(q.getModifier());
    vo.setModifyTime(q.getModifyTime());
    vo.setRemark(q.getRemark());
    vo.setQuoteRemark(q.getQuoteRemark());
    vo.setTotalAmount(q.getTotalAmount());

    List<QuoteItemVO> items = new ArrayList<>();
    for (QuotationItem item : quotationItemMapper.selectByQuotationId(q.getId())) {
      QuoteItemVO itemVO = new QuoteItemVO();
      itemVO.setId(item.getId());
      itemVO.setRequirementItemId(item.getRequirementItemId());
      itemVO.setPartNo(item.getPartNo());
      itemVO.setReplaceNo(item.getReplaceNo());
      itemVO.setPartName(item.getPartName());
      itemVO.setQuantity(item.getQuantity());
      itemVO.setUnitPrice(item.getUnitPrice());
      itemVO.setUnit(item.getUnit());
      itemVO.setSpec(item.getSpec());
      itemVO.setPurchaseRemark(item.getPurchaseRemark());
      itemVO.setQuoteRemark(item.getQuoteRemark());
      items.add(itemVO);
    }
    vo.setItems(items);
    return vo;
  }

  /** 计算状态（quoting / pending / awarded）与排名（截止后有效） */
  private void fillStatusAndRank(List<QuotationVO> list) {
    if (list == null || list.isEmpty()) {
      return;
    }
    Set<Long> reqIds = new HashSet<>();
    for (QuotationVO vo : list) {
      reqIds.add(vo.getRequirementId());
    }
    Map<Long, AwardResult> awards = rankSupport.awardsOf(reqIds);
    Map<Long, Integer> expiredRanks = rankSupport.ranksOf(reqIds);
    LocalDateTime now = LocalDateTime.now();
    for (QuotationVO vo : list) {
      boolean expired = vo.getQuoteDeadline() != null && vo.getQuoteDeadline().isBefore(now);
      vo.setExpired(expired);
      if (!expired) {
        vo.setStatus("quoting");
        vo.setRank(null);
        continue;
      }
      AwardResult award = awards.get(vo.getRequirementId());
      if (award != null && award.getQuoteNo() != null && award.getQuoteNo().equals(vo.getQuoteNo())) {
        vo.setStatus("awarded");
      } else {
        vo.setStatus("pending");
      }
      vo.setRank(expiredRanks.get(vo.getId()));
    }
  }
}
