package com.songlin.bidding.service.impl;

import com.songlin.bidding.common.BusinessException;
import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.dto.RequirementItemVO;
import com.songlin.bidding.dto.RequirementQuery;
import com.songlin.bidding.dto.RequirementSaveRequest;
import com.songlin.bidding.dto.RequirementVO;
import com.songlin.bidding.entity.PurchaseRequirement;
import com.songlin.bidding.entity.RequirementItem;
import com.songlin.bidding.mapper.AwardResultMapper;
import com.songlin.bidding.mapper.PurchaseRequirementMapper;
import com.songlin.bidding.mapper.QuotationMapper;
import com.songlin.bidding.mapper.RequirementItemMapper;
import com.songlin.bidding.service.RequirementService;
import com.songlin.bidding.util.DateTimeUtil;
import com.songlin.bidding.util.NoGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 采购需求实现
 */
@Service
@RequiredArgsConstructor
public class RequirementServiceImpl implements RequirementService {

  private final PurchaseRequirementMapper requirementMapper;
  private final RequirementItemMapper itemMapper;
  private final QuotationMapper quotationMapper;
  private final AwardResultMapper awardResultMapper;
  private final NoGenerator noGenerator;

  @Override
  public PageResult<RequirementVO> page(RequirementQuery query) {
    // 采购员只看到自己创建的需求，管理员与供应商不受限
    if (UserContext.isPurchaser()) {
      query.setCreatorFilter(UserContext.currentName());
    } else {
      query.setCreatorFilter(null);
    }
    List<RequirementVO> list = requirementMapper.selectPage(query);
    long total = requirementMapper.countPage(query);
    return PageResult.of(list, total, query.getPageNum(), query.getPageSize());
  }

  @Override
  public RequirementVO detail(Long id) {
    PurchaseRequirement r = getEntity(id);
    RequirementVO vo = toVO(r);
    List<RequirementItemVO> items = buildItemVOs(id);
    vo.setItems(items);
    vo.setItemCount(items.size());
    return vo;
  }

  @Override
  public String nextReqNo() {
    return noGenerator.reqNo();
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public Long publish(RequirementSaveRequest request) {
    if (request.getItems() == null || request.getItems().isEmpty()) {
      throw new BusinessException("请至少新增一条商品");
    }
    int idx = 0;
    for (RequirementSaveRequest.Item item : request.getItems()) {
      idx++;
      if (!StringUtils.hasText(item.getPartNo()) || !StringUtils.hasText(item.getPartName())) {
        throw new BusinessException("第 " + idx + " 行商品信息不完整，请检查必填项（配件图号、配件名称）");
      }
      if (item.getQuantity() == null || item.getQuantity() <= 0) {
        throw new BusinessException("第 " + idx + " 行商品采购数量必须大于 0");
      }
    }

    LocalDateTime deadline = DateTimeUtil.parseDateTime(request.getQuoteDeadline());
    LocalDate deliverDate = DateTimeUtil.parseDate(request.getDeliverDate());
    if (deadline == null) {
      throw new BusinessException("请选择报价截止日期");
    }
    if (deliverDate == null) {
      throw new BusinessException("请选择集中交货日期");
    }

    LocalDateTime now = LocalDateTime.now();
    String operator = UserContext.currentName();
    Long requirementId;

    if (request.getId() == null) {
      PurchaseRequirement r = new PurchaseRequirement();
      r.setReqNo(noGenerator.reqNo());
      r.setQuoteDeadline(deadline);
      r.setDeliverDate(deliverDate);
      r.setCreator(operator);
      r.setCreateTime(now);
      r.setModifier(operator);
      r.setModifyTime(now);
      r.setRemark(request.getRemark());
      requirementMapper.insert(r);
      requirementId = r.getId();
    } else {
      PurchaseRequirement r = getEntity(request.getId());
      r.setQuoteDeadline(deadline);
      r.setDeliverDate(deliverDate);
      r.setRemark(request.getRemark());
      r.setModifier(operator);
      r.setModifyTime(now);
      requirementMapper.update(r);
      requirementId = r.getId();
    }

    saveItems(requirementId, request.getItems());

    // 重新发布后清空该需求的历史报价与中标记录，保证 需求 -> 报价 -> 排名确认 串联完整
    quotationMapper.logicDeleteByRequirementId(requirementId);
    awardResultMapper.deleteByRequirementId(requirementId);
    return requirementId;
  }

  /** 商品清单增量保存：按 id 更新、无 id 新增、缺失的删除，发布后统一置为已发布 */
  private void saveItems(Long requirementId, List<RequirementSaveRequest.Item> items) {
    Map<Long, RequirementItem> existMap = new HashMap<>();
    for (RequirementItem e : itemMapper.selectByRequirementId(requirementId)) {
      existMap.put(e.getId(), e);
    }
    int sort = 0;
    for (RequirementSaveRequest.Item item : items) {
      sort++;
      RequirementItem entity = item.getId() == null ? null : existMap.remove(item.getId());
      if (entity == null) {
        entity = new RequirementItem();
        entity.setRequirementId(requirementId);
        entity.setPublished(1);
        entity.setSortOrder(sort);
        fill(entity, item);
        itemMapper.insert(entity);
      } else {
        fill(entity, item);
        entity.setPublished(1);
        entity.setSortOrder(sort);
        itemMapper.update(entity);
      }
    }
    for (RequirementItem removed : existMap.values()) {
      itemMapper.logicDelete(removed.getId());
    }
  }

  private void fill(RequirementItem entity, RequirementSaveRequest.Item item) {
    entity.setPartNo(item.getPartNo().trim());
    entity.setReplaceNo(item.getReplaceNo());
    entity.setPartName(item.getPartName().trim());
    entity.setQuantity(item.getQuantity());
    entity.setUnit(item.getUnit());
    entity.setSpec(item.getSpec());
    entity.setPurchaseRemark(item.getPurchaseRemark());
  }

  private PurchaseRequirement getEntity(Long id) {
    PurchaseRequirement r = requirementMapper.selectById(id);
    if (r == null || Integer.valueOf(1).equals(r.getDeleted())) {
      throw new BusinessException("采购需求不存在或已被删除");
    }
    return r;
  }

  private RequirementVO toVO(PurchaseRequirement r) {
    RequirementVO vo = new RequirementVO();
    vo.setId(r.getId());
    vo.setReqNo(r.getReqNo());
    vo.setQuoteDeadline(r.getQuoteDeadline());
    vo.setDeliverDate(r.getDeliverDate());
    vo.setCreator(r.getCreator());
    vo.setCreateTime(r.getCreateTime());
    vo.setModifier(r.getModifier());
    vo.setModifyTime(r.getModifyTime());
    vo.setRemark(r.getRemark());
    if (r.getQuoteDeadline() != null && r.getQuoteDeadline().isAfter(LocalDateTime.now())) {
      vo.setStatus("quoting");
    } else {
      vo.setStatus("expired");
    }
    return vo;
  }

  private List<RequirementItemVO> buildItemVOs(Long requirementId) {
    List<RequirementItemVO> vos = new ArrayList<>();
    for (RequirementItem item : itemMapper.selectByRequirementId(requirementId)) {
      RequirementItemVO vo = new RequirementItemVO();
      vo.setId(item.getId());
      vo.setPartNo(item.getPartNo());
      vo.setReplaceNo(item.getReplaceNo());
      vo.setPartName(item.getPartName());
      vo.setQuantity(item.getQuantity());
      vo.setUnit(item.getUnit());
      vo.setSpec(item.getSpec());
      vo.setPurchaseRemark(item.getPurchaseRemark());
      vo.setPublished(Integer.valueOf(1).equals(item.getPublished()));
      vos.add(vo);
    }
    return vos;
  }
}
