package com.songlin.bidding.service.impl;

import com.songlin.bidding.common.BusinessException;
import com.songlin.bidding.common.PageResult;
import com.songlin.bidding.common.UserContext;
import com.songlin.bidding.dto.UserAccountVO;
import com.songlin.bidding.dto.UserQuery;
import com.songlin.bidding.dto.UserSaveRequest;
import com.songlin.bidding.entity.SysUser;
import com.songlin.bidding.mapper.SysUserMapper;
import com.songlin.bidding.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 用户管理实现
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

  /** 新增用户时的默认密码 */
  private static final String DEFAULT_PASSWORD = "123456";

  private final SysUserMapper sysUserMapper;
  private final PasswordEncoder passwordEncoder;

  @Override
  public PageResult<UserAccountVO> page(UserQuery query) {
    List<UserAccountVO> list = sysUserMapper.selectPage(query);
    long total = sysUserMapper.countPage(query);
    return PageResult.of(list, total, query.getPageNum(), query.getPageSize());
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public Long save(UserSaveRequest request) {
    String phone = request.getPhone().trim();
    if (phoneExists(phone, request.getId())) {
      throw new BusinessException("该手机号已被占用");
    }
    String username = StringUtils.hasText(request.getUsername())
        ? request.getUsername().trim()
        : phone;
    if (sysUserMapper.countByUsername(username, request.getId()) > 0) {
      throw new BusinessException("登录账号已存在：" + username);
    }

    if (request.getId() == null) {
      SysUser user = new SysUser();
      user.setUsername(username);
      user.setPassword(passwordEncoder.encode(
          StringUtils.hasText(request.getPassword()) ? request.getPassword() : DEFAULT_PASSWORD));
      user.setPhone(phone);
      user.setName(request.getName().trim());
      user.setEmail(request.getEmail().trim());
      user.setCompany(request.getCompany().trim());
      user.setRole(request.getRole());
      user.setEnabled(Boolean.TRUE.equals(request.getEnabled()) ? 1 : 0);
      sysUserMapper.insert(user);
      return user.getId();
    }

    SysUser user = sysUserMapper.selectById(request.getId());
    if (user == null) {
      throw new BusinessException("用户不存在或已被删除");
    }
    user.setUsername(username);
    user.setPhone(phone);
    user.setName(request.getName().trim());
    user.setEmail(request.getEmail().trim());
    user.setCompany(request.getCompany().trim());
    user.setRole(request.getRole());
    user.setEnabled(Boolean.TRUE.equals(request.getEnabled()) ? 1 : 0);
    if (StringUtils.hasText(request.getPassword())) {
      user.setPassword(passwordEncoder.encode(request.getPassword()));
    }
    sysUserMapper.update(user);
    return user.getId();
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void delete(Long id) {
    Long currentId = UserContext.currentUserId();
    if (id != null && id.equals(currentId)) {
      throw new BusinessException("不能删除当前登录账号");
    }
    SysUser user = sysUserMapper.selectById(id);
    if (user == null) {
      throw new BusinessException("用户不存在或已被删除");
    }
    sysUserMapper.logicDelete(id);
  }

  @Override
  public boolean phoneExists(String phone, Long excludeId) {
    if (!StringUtils.hasText(phone)) {
      return false;
    }
    return sysUserMapper.countByPhone(phone.trim(), excludeId) > 0;
  }
}
