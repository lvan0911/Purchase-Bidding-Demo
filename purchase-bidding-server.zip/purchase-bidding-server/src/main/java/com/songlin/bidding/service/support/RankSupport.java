package com.songlin.bidding.service.support;

import com.songlin.bidding.entity.AwardResult;
import com.songlin.bidding.entity.Quotation;
import com.songlin.bidding.mapper.AwardResultMapper;
import com.songlin.bidding.mapper.QuotationMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 排名与中标状态计算：
 * 报价截止前不排名；截止后按报价金额从低到高排名，第一名即"推荐中标"
 */
@Component
@RequiredArgsConstructor
public class RankSupport {

  private final QuotationMapper quotationMapper;
  private final AwardResultMapper awardResultMapper;

  /** 需求 ID -&gt; 中标记录 */
  public Map<Long, AwardResult> awardsOf(Collection<Long> requirementIds) {
    Map<Long, AwardResult> map = new HashMap<>();
    if (requirementIds == null) {
      return map;
    }
    for (Long reqId : requirementIds) {
      if (reqId == null) {
        continue;
      }
      AwardResult award = awardResultMapper.selectByRequirementId(reqId);
      if (award != null) {
        map.put(reqId, award);
      }
    }
    return map;
  }

  /** 报价单 ID -&gt; 排名（同一需求内按金额升序） */
  public Map<Long, Integer> ranksOf(Collection<Long> requirementIds) {
    Map<Long, Integer> ranks = new HashMap<>();
    if (requirementIds == null) {
      return ranks;
    }
    for (Long reqId : requirementIds) {
      if (reqId == null) {
        continue;
      }
      List<Quotation> list = quotationMapper.selectByRequirementId(reqId);
      list.sort(Comparator
          .comparing((Quotation q) -> q.getTotalAmount() == null ? BigDecimal.ZERO : q.getTotalAmount())
          .thenComparing(Quotation::getConfirmDeliverDate, Comparator.nullsLast(Comparator.naturalOrder()))
          .thenComparing(Quotation::getId));
      int i = 1;
      for (Quotation q : list) {
        ranks.put(q.getId(), i++);
      }
    }
    return ranks;
  }
}
