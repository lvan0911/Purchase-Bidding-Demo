package com.songlin.bidding.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 日期时间解析：兼容 yyyy-MM-dd 与 yyyy-MM-dd HH:mm:ss
 */
public final class DateTimeUtil {

  public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  public static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

  private DateTimeUtil() {
  }

  public static LocalDate parseDate(String text) {
    if (text == null || text.isBlank()) {
      return null;
    }
    String v = text.trim();
    return LocalDate.parse(v.length() > 10 ? v.substring(0, 10) : v, DATE);
  }

  public static LocalDateTime parseDateTime(String text) {
    if (text == null || text.isBlank()) {
      return null;
    }
    String v = text.trim();
    if (v.length() <= 10) {
      return LocalDate.parse(v, DATE).atStartOfDay();
    }
    return LocalDateTime.parse(v, DATE_TIME);
  }
}
