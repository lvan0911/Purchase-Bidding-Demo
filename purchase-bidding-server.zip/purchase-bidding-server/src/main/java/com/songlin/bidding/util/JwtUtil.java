package com.songlin.bidding.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

/**
 * JWT 工具类（jjwt 0.12.x）
 */
@Slf4j
@Component
public class JwtUtil {

  private final SecretKey secretKey;
  private final long expireMillis;

  public JwtUtil(@Value("${app.jwt.secret}") String secret,
                 @Value("${app.jwt.expire-hours}") long expireHours) {
    this.secretKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));
    this.expireMillis = expireHours * 60 * 60 * 1000L;
  }

  /** 生成 token，subject 存放登录账号 */
  public String generateToken(Long userId, String username) {
    Date now = new Date();
    return Jwts.builder()
        .subject(username)
        .claim("uid", userId)
        .issuedAt(now)
        .expiration(new Date(now.getTime() + expireMillis))
        .signWith(secretKey)
        .compact();
  }

  /** 解析 token，失败返回 null */
  public Claims parse(String token) {
    try {
      return Jwts.parser()
          .verifyWith(secretKey)
          .build()
          .parseSignedClaims(token)
          .getPayload();
    } catch (JwtException | IllegalArgumentException e) {
      log.debug("token 解析失败：{}", e.getMessage());
      return null;
    }
  }

  public String getUsername(String token) {
    Claims claims = parse(token);
    return claims == null ? null : claims.getSubject();
  }
}
