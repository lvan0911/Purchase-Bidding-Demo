package com.songlin.bidding.util;

import com.songlin.bidding.mapper.PurchaseRequirementMapper;
import com.songlin.bidding.mapper.QuotationMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * 单号生成器
 * 需求单号：XQ + yyyyMMdd + 4位序号
 * 报价单号：BJ + yyyyMMdd + 4位序号
 */
@Component
@RequiredArgsConstructor
public class NoGenerator {

  private static final DateTimeFormatter COMPACT = DateTimeFormatter.ofPattern("yyyyMMdd");

  private final PurchaseRequirementMapper requirementMapper;
  private final QuotationMapper quotationMapper;

  public synchronized String reqNo() {
    String prefix = "XQ" + LocalDate.now().format(COMPACT);
    return nextNo(prefix, requirementMapper.selectMaxNo(prefix));
  }

  public synchronized String quoteNo() {
    String prefix = "BJ" + LocalDate.now().format(COMPACT);
    return nextNo(prefix, quotationMapper.selectMaxNo(prefix));
  }

  private String nextNo(String prefix, String maxNo) {
    int seq = 0;
    if (maxNo != null && maxNo.length() >= 4) {
      try {
        seq = Integer.parseInt(maxNo.substring(maxNo.length() - 4));
      } catch (NumberFormatException ignored) {
        seq = 0;
      }
    }
    return prefix + String.format("%04d", seq + 1);
  }
}
