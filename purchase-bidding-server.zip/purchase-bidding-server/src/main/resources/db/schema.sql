-- =============================================================
-- 松林科技采购竞价系统 - MySQL 数据库脚本
-- 版本：MySQL 5.7+ / 8.0
-- 执行方式：mysql -u root -p < src/main/resources/db/schema.sql
-- =============================================================

CREATE DATABASE IF NOT EXISTS `purchase_bidding`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE `purchase_bidding`;

-- -------------------------------------------------------------
-- 1. 系统用户表（登录账号 + 用户管理）
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username`    VARCHAR(64)  NOT NULL                COMMENT '登录账号',
  `password`    VARCHAR(128) NOT NULL                COMMENT '登录密码（BCrypt 加密）',
  `phone`       VARCHAR(20)  NOT NULL                COMMENT '账号（手机号）',
  `name`        VARCHAR(64)  NOT NULL                COMMENT '姓名',
  `email`       VARCHAR(128) DEFAULT NULL            COMMENT '邮箱',
  `company`     VARCHAR(128) DEFAULT NULL            COMMENT '公司名称',
  `role`        VARCHAR(20)  NOT NULL DEFAULT 'supplier' COMMENT '角色：admin-管理员 / purchaser-采购员 / supplier-供应商',
  `enabled`     TINYINT(1)   NOT NULL DEFAULT 1      COMMENT '状态：1-启用 0-禁用',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `deleted`     TINYINT(1)   NOT NULL DEFAULT 0      COMMENT '逻辑删除：1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_user_username` (`username`, `deleted`),
  UNIQUE KEY `uk_sys_user_phone` (`phone`, `deleted`),
  KEY `idx_sys_user_role` (`role`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '系统用户表';

-- -------------------------------------------------------------
-- 2. 采购需求单
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `purchase_requirement`;
CREATE TABLE `purchase_requirement` (
  `id`             BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
  `req_no`         VARCHAR(32) NOT NULL                COMMENT '需求单号：XQ + yyyyMMdd + 4位序号',
  `quote_deadline` DATETIME    NOT NULL                COMMENT '报价截止日期',
  `deliver_date`   DATE        NOT NULL                COMMENT '集中交货日期',
  `creator`        VARCHAR(64) NOT NULL                COMMENT '创建人',
  `create_time`    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modifier`       VARCHAR(64) DEFAULT NULL            COMMENT '修改人',
  `modify_time`    DATETIME    DEFAULT NULL            COMMENT '修改时间',
  `remark`         VARCHAR(500) DEFAULT NULL           COMMENT '需求单备注',
  `deleted`        TINYINT(1)  NOT NULL DEFAULT 0      COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_requirement_req_no` (`req_no`),
  KEY `idx_requirement_deadline` (`quote_deadline`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '采购需求单';

-- -------------------------------------------------------------
-- 3. 采购需求商品明细
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `requirement_item`;
CREATE TABLE `requirement_item` (
  `id`               BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `requirement_id`   BIGINT       NOT NULL                COMMENT '需求单 ID',
  `part_no`          VARCHAR(64)  NOT NULL                COMMENT '配件图号',
  `replace_no`       VARCHAR(64)  DEFAULT NULL            COMMENT '通用/替换号',
  `part_name`        VARCHAR(128) NOT NULL                COMMENT '配件名称',
  `quantity`         INT          NOT NULL                COMMENT '采购数量',
  `unit`             VARCHAR(16)  DEFAULT NULL            COMMENT '单位',
  `spec`             VARCHAR(128) DEFAULT NULL            COMMENT '规格型号',
  `purchase_remark`  VARCHAR(255) DEFAULT NULL            COMMENT '采购备注',
  `published`        TINYINT(1)   NOT NULL DEFAULT 0      COMMENT '是否已发布：1-已发布（发布后不可编辑）',
  `sort_order`       INT          NOT NULL DEFAULT 0      COMMENT '排序号',
  `deleted`          TINYINT(1)   NOT NULL DEFAULT 0      COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_req_item_requirement_id` (`requirement_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '采购需求商品明细';

-- -------------------------------------------------------------
-- 4. 供应商报价单（同一需求 + 同一报价人 唯一）
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `quotation`;
CREATE TABLE `quotation` (
  `id`                   BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `quote_no`             VARCHAR(32)   NOT NULL                COMMENT '报价单号：BJ + yyyyMMdd + 4位序号',
  `requirement_id`       BIGINT        NOT NULL                COMMENT '需求单 ID',
  `req_no`               VARCHAR(32)   NOT NULL                COMMENT '需求单号（冗余上游）',
  `quote_deadline`       DATETIME      NOT NULL                COMMENT '报价截止日期（冗余上游）',
  `deliver_date`         DATE          NOT NULL                COMMENT '集中交货日期（冗余上游）',
  `confirm_deliver_date` DATE          NOT NULL                COMMENT '确定交货日期（报价方填写）',
  `quote_person`         VARCHAR(64)   NOT NULL                COMMENT '报价人',
  `quote_user_id`        BIGINT        DEFAULT NULL            COMMENT '报价人账号 ID',
  `quote_time`           DATETIME      NOT NULL                COMMENT '报价时间（首次提交生成）',
  `modifier`             VARCHAR(64)   DEFAULT NULL            COMMENT '修改人',
  `modify_time`          DATETIME      DEFAULT NULL            COMMENT '修改时间',
  `remark`               VARCHAR(500)  DEFAULT NULL            COMMENT '备注（冗余上游）',
  `quote_remark`         VARCHAR(500)  DEFAULT NULL            COMMENT '报价备注（报价方填写）',
  `total_amount`         DECIMAL(16,2) NOT NULL DEFAULT 0.00   COMMENT '报价合计金额',
  `award_status`         TINYINT(1)    NOT NULL DEFAULT 0      COMMENT '中标状态：0-待确认 1-已中标 2-未中标',
  `deleted`              TINYINT(1)    NOT NULL DEFAULT 0      COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_quotation_quote_no` (`quote_no`),
  UNIQUE KEY `uk_quotation_req_person` (`requirement_id`, `quote_person`, `deleted`),
  KEY `idx_quotation_user` (`quote_user_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '供应商报价单';

-- -------------------------------------------------------------
-- 5. 报价商品明细
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `quotation_item`;
CREATE TABLE `quotation_item` (
  `id`                  BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `quotation_id`        BIGINT        NOT NULL                COMMENT '报价单 ID',
  `requirement_item_id` BIGINT        NOT NULL                COMMENT '需求商品行 ID',
  `part_no`             VARCHAR(64)   NOT NULL                COMMENT '配件图号',
  `replace_no`          VARCHAR(64)   DEFAULT NULL            COMMENT '通用/替换号',
  `part_name`           VARCHAR(128)  NOT NULL                COMMENT '配件名称',
  `quantity`            INT           NOT NULL                COMMENT '采购数量',
  `unit`                VARCHAR(16)   DEFAULT NULL            COMMENT '单位',
  `spec`                VARCHAR(128)  DEFAULT NULL            COMMENT '规格型号',
  `purchase_remark`     VARCHAR(255)  DEFAULT NULL            COMMENT '采购备注（冗余上游）',
  `unit_price`          DECIMAL(16,2) DEFAULT NULL            COMMENT '单价（报价方填写）',
  `quote_remark`        VARCHAR(255)  DEFAULT NULL            COMMENT '该行报价备注',
  `sort_order`          INT           NOT NULL DEFAULT 0      COMMENT '排序号',
  PRIMARY KEY (`id`),
  KEY `idx_quote_item_quotation_id` (`quotation_id`),
  KEY `idx_quote_item_req_item_id` (`requirement_item_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '报价商品明细';

-- -------------------------------------------------------------
-- 6. 中标结果（一个需求单一条中标记录）
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `award_result`;
CREATE TABLE `award_result` (
  `id`                   BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `requirement_id`       BIGINT        NOT NULL                COMMENT '需求单 ID',
  `req_no`               VARCHAR(32)   NOT NULL                COMMENT '需求单号',
  `quotation_id`         BIGINT        NOT NULL                COMMENT '中标报价单 ID',
  `quote_no`             VARCHAR(32)   NOT NULL                COMMENT '中标报价单号',
  `supplier_name`        VARCHAR(64)   NOT NULL                COMMENT '中标供应商（报价人）',
  `award_price`          DECIMAL(16,2) NOT NULL DEFAULT 0.00   COMMENT '中标价格',
  `confirm_deliver_date` DATE          DEFAULT NULL            COMMENT '确定交货日期',
  `confirm_time`         DATETIME      NOT NULL                COMMENT '确认时间',
  `operator`             VARCHAR(64)   DEFAULT NULL            COMMENT '确认人',
  `confirmed`            TINYINT(1)    NOT NULL DEFAULT 1      COMMENT '已确认：1-是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_award_requirement_id` (`requirement_id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '中标结果';

-- -------------------------------------------------------------
-- 初始化演示账号：服务首次启动时由 DataInitializer 自动写入
--   admin / 123456（管理员）
--   zhangsan / 123456（采购员）
--   lisi / 123456（供应商）
--   wangwu / 123456（供应商）
-- -------------------------------------------------------------
